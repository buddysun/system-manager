<?php
namespace Admin\Controller;
/*
 * 代付控制器
 * wenjinghao
 */
class PayforuserController extends AdminController{
    protected $order_type_label = array(
        '0'=>'普通订单',
        '2'=>'回款订单',
        '3'=>'预付款订单',
        '4'=>'保证金订单'
    );
    protected $m_order_type = array(
        '6'=>'厂商订单',
        '7'=>'回款订单'
    );
    protected $cache_list = array(
        'supplier_detail'=>'wenjinghao_jingxiaoshangdaifu_detail_20151015',
        'supplier_summary'=>'wenjinghao_jingxiaoshangdaifu_summary_20151015',
        'manufacturer_detail'=>'wenjinghao_lingshoudiandaifu_detail_20151015',
        'manufacturer_summary'=>'wenjinghao_lingshoudiandaifu_summary_20151015'
    );
    //经销商代付
    public function supplier(){
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);
        
        //经销商账号
        $supplier_login_name = I('keywords', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        $start =  I('start_time', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        $end =  I('end_time', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        
        $start = empty($start)? date('Y-m-d',strtotime('-1 day')) : $start;
        $end = empty($end)? date('Y-m-d',strtotime('-1 day')) : $end;
        
        $ctime = strtotime(date('Y-m-d 00:00:00', time()));//昨天的时间戳
        $my_start = date('Y-m-d 00:00:00', time());
        $my_end = date('Y-m-d 23:59:59', time());
        
        $c_start = $start . ' 00:00:00';
        $c_end = $end . ' 23:59:59';
        
        //查询条件
        $where = array();
        
        //起始日期
        if(strtotime($c_start)!==false){
            //只能选择昨天或者 早已昨天 否则会提示出错
            //if(strtotime($c_start) > $ctime){
               // $this->error('只能选择昨天或者之前的日期！');
            //}
        
           // $my_start = date('Y-m-d 00:00:00', strtotime($start));
           // $sql_where .= "A.pay_date>='{$my_start}' and ";
            $where['pay_date'] = $start;
        }
        
        //if(strtotime($c_start)> strtotime($c_end)){
            //$this->error('起始日期不能大于截止日期！');
        //}
        
        $param = array(
            'keywords'=>$supplier_login_name,
            'start_time'=>$start
        );
        
        
        $supplier_login_name = trim($supplier_login_name);
        
        if($supplier_login_name){
            $where['_string'] = "supplier_login_name like '%$supplier_login_name%'";
        }

        //缓存查询日期 供导出列表的时候使用
        session('wenjinghao_20151017_s_daifu_day', $start);
        
        //获取经销商代付的汇总
        $m = M('supplier_pay_remittance_summary');
        $count = $m->where($where)->count();
        $total_price = $m->where($where)->sum('amount');

        
        $pageSize = 25;
        $Page = new \Think\Page($count,$pageSize);
        
        $offset = $Page->firstRow;
        
        $setpagenum = I('get.setpagenum', 20, 'intval');
        $p = I('get.p', 0, 'intval');
        
        $Page->listRows = $setpagenum;
        
        $_page = $Page->show();

       $list = $m->where($where)->page($p.','.$Page->listRows)->select();
       

       $total_price = $total_price? $total_price: 0.00;

        //总的统计
        $total_info = array(
            'count'=>$count? $count: 0,
            'total_price'=>$total_price,
            //'merchant_id'=>'898440342250013',
            'merchant_id'=>'000191400205187',
            'code'=>'09100',
            'date'=>date('Ymd', time())
        );

        $i = $offset+1;
        
        //缓存要导出的数据列表
        $exportList = array(
            'queryDate'=> '('.substr($start,0,10) . '~' . substr($end,0,10).')',
            'list'=>array()
        );
        
        //当前页的总金额
        $current_amout_info = array_values(array_column($list, 'amount'));
        $current_amout = array_sum($current_amout_info);
        $current_amout = $current_amout? $current_amout : 0.00;
        
        $exportList['list'][] = array(
            'serial_number'=>'F',//收付标志或者记录序号
            'merchant_id'=>$total_info['merchant_id'],//商户ID或者列表的空列
            'date_code'=>date('Ymd', time()),//提交日期或者列表的银行代码
            'num_blank'=>count($list),//总笔数或者列表的空列
            'amout_bank_number'=>$current_amout,//总金额或者列表的银行账户
            'code_unit_name'=>$total_info['code'],//业务类型或者列表的银行开户人名称
            'province'=>'',//列表的省份或者总信息的空格
            'city'=>'',//列表的城市或者总信息的空格
            'blank_one'=>'',//空格
            'blank_tow'=>'',//空格
            'amout'=>''//列表的金额或者总信息的空格
        );
        
        //缓存经销商id
        $sidArr = array();
        //当前网点名称
        $current_bank_name = '';
        
        foreach($list as $key=>$val){
            $list[$key]['serial_number'] = $this->getSerialnumber($i);
            
            $status = $list[$key]['status']==1? '未打款' : '已打款';
            $list[$key]['status'] = $status;
            
            $sidArr[] = $val['supplier_id'];
            
            //获取开户行网点
            if($val['supplier_id']){
                $current_bank_name = $this->getTransferbankName($val['supplier_id'], 1);
            }
            
           $i++;
        }
        
        //要导出的数据列表
        $j = 1;
        $new_current_bank_name = '';
        $daochu_list = $m->where($where)->select();

        foreach($daochu_list as $data_key=>$data_val){
            //$daochu_list[$data_key]['serial_number'] = $this->getSerialnumber($j);
        
            //$status = $daochu_list[$data_key]['status']==1? '未打款' : '已打款';
            //$daochu_list[$data_key]['status'] = $status;
        
            //获取开户行网点
            if($data_val['supplier_id']){
                $new_current_bank_name = $this->getTransferbankName($data_val['supplier_id'], 1);
            }
        
            //汇总的导出模板
            $exportList['list'][] = array(
                'serial_number'=>$this->getSerialnumber($j),//收付标志或者记录序号
                'merchant_id'=>'',//商户ID或者列表的空列
                'date_code'=> $data_val['bank_code'],//提交日期或者列表的银行代码
                'num_blank'=>'',//总笔数或者列表的空列
                'amout_bank_number'=>$data_val['transfer_account'],//总金额或者列表的银行账户
                'code_unit_name'=> $data_val['transfer_name'],//业务类型或者列表的银行开户人名称
                'province'=>$data_val['province'],//列表的省份或者总信息的空格
                'city'=>$data_val['city'],//列表的城市或者总信息的空格
                'blank_one'=> $new_current_bank_name,//空格
                'blank_tow'=>'',//空格
                'amout'=>$data_val['amount']-$data_val['factorage']//列表的金额或者总信息的空格
            );
             
            $j++;
        }
        
        //保存经销商id到session 供选择导出的时候使用
        session('wenjinghao_20151017_s_daifu_sid', $sidArr);
        
        $cache_key = $this->cache_list['supplier_summary'];
        S($cache_key, $exportList);
        
        $this->assign('total_info', $total_info);
        $this->assign('list', $list);
        $this->assign('param',$param);
        $this->assign('_page', $_page);
        $this->assign('currentDay', $start);
        $this->select_menu = U('Payforuser/supplier');
        $this->display();
    }
    
    //经销商明细
    public function supplierDetail(){
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);
        
        //经销商账号或者零售店账号
        $m_name = I('keywords', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        $start =  I('start_time', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        $end =  I('end_time', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        $status = I('status', '0', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        
        $start = empty($start)? date('Y-m-d',strtotime('-1 day')) : $start;
        $end = empty($end)? date('Y-m-d',strtotime('-1 day')) : $end;
        
        
        $ctime = strtotime(date('Y-m-d 00:00:00', time()));//昨天的时间戳
        $my_start = date('Y-m-d 00:00:00', time());
        $my_end = date('Y-m-d 23:59:59', time());

        //查询条件
        $where = array();
        
        $c_start = $start . ' 00:00:00';
        $c_end = $end . ' 23:59:59';
        
        //起始日期
        if(strtotime($c_start)!==false){
            //只能选择昨天或者 早已昨天 否则会提示出错
            //if(strtotime($c_start) > $ctime){
                //$this->error('只能选择昨天或者之前的日期！');
           // }
        
            $my_start = date('Y-m-d 00:00:00', strtotime($start));
            //$where['A.pay_date'][] = array('egt', $my_start);
            $where['pay_time'][] = array('egt', $my_start);
        }
        
        if(strtotime($c_start)> strtotime($c_end)){
            $this->error('起始日期不能大于截止日期！');
        }
        
        //结束日期
        if(strtotime($c_end)!==false){
            //只能选择昨天或者 早已昨天 否则会提示出错
            //if(strtotime($c_end) > $ctime){
                //$this->error('只能选择昨天或者之前的日期！');
            //}
        
            $my_end = date('Y-m-d 23:59:59', strtotime($end));
            $where['pay_time'][] = array('elt', $my_end);
            
        }
        
        $param = array(
            'keywords'=>$m_name,
            'start_time'=>$start,
            'end_time'=>$end,
            'status'=>$status
        );
        
        //验证开始日期和结束日期的时间间隔不能超过90天
        $endTime = strtotime($my_end);
        $startTime = strtotime($my_start);
        $intervalDay = ceil(($endTime-$startTime)/86400);
        
        if($intervalDay>90){
            $this->error('查询的时间段不能超过90天');
        }
        
        $m_name = trim($m_name);
        
        if($m_name){
            //$sql_where .= "m_name like '%$m_name%' and ";
            $where['_string'] = "supplier_name like '%$m_name%' OR order_sn like '%$m_name%'";
        }
        
        if($status){
            $where['status'] = $status;
        }
        
        $m = M('supplier_order_pay_remittance_detail');
        
        //获取经销商代付的明细
        $list = array();
        $count = $m->where($where)->count();
        $pageSize = 50;
        $Page = new \Think\Page($count,$pageSize);
        
        $offset = $Page->firstRow;

        $setpagenum = I('get.setpagenum', 50, 'intval');
        $p = I('get.p', 0, 'intval');
        $Page->listRows = $setpagenum;

        $_page = $Page->show();
        
        $list = $m->where($where)->order('pay_time desc')->page($p.','.$Page->listRows)->select();

        //缓存要导出的数据列表
        $exportList = array(
            'queryDate'=> '('.substr($start,0,10) . '~' . substr($end,0,10).')',
            'list'=>array()
        );
        
        
        foreach($list as $key=>$val){
            $list[$key]['pay_time'] = substr($val['pay_time'],0,10);

            //订单类型 和支付方式
            $list[$key]['order_type'] = $this->order_type_label[$val['order_type']];
            //支付类型 1 银联在线 2 pos支付
            $method = $val['pay_method'];
            $list[$key]['pay_method'] = $method==0? '银联在线' : 'pos支付';
            
            $status = $list[$key]['status']==1? '未打款' : '已打款';
            $list[$key]['status'] = $status;
        }
        
        //要导出的数据列表
        $daochu_list = $m->where($where)->order('pay_time desc')->select();
        
        foreach($daochu_list as $data_key=>$data_val){
            $daochu_list[$data_key]['pay_time'] = substr($data_val['pay_time'],0,10);
        
            //订单类型 和支付方式
            $daochu_list[$data_key]['order_type'] = $this->order_type_label[$data_val['order_type']];
            //支付类型 1 银联在线 2 pos支付
            $method = $data_val['pay_method'];
            $daochu_list[$data_key]['pay_method'] = $method==0? '银联在线' : 'pos支付';
        
            $status = $list[$data_key]['status']==1? '未打款' : '已打款';
            $daochu_list[$data_key]['status'] = $status;
        
            $exportList['list'][] = array(
                'pay_date' => $daochu_list[$data_key]['pay_time'],
                'supplier_login_name' => $data_val['supplier_login_name'],
                'supplier_name'=> $data_val['supplier_name'],
                'user_login_name' => $data_val['user_login_name'],
                'user_name' => $data_val['user_name'],
                'order_sn'=>$data_val['order_sn'],
                'order_type' => $daochu_list[$data_key]['order_type'],
                'pay_method' => $daochu_list[$data_key]['pay_method'],
                'order_amount'=>$data_val['pay_price'],
                'factorage_amount'=> $data_val['factorage'],
                'transfer_amount'=>$data_val['pay_price']-$data_val['factorage']
            );
        }
        
        $cache_key = $this->cache_list['supplier_detail'];
        S($cache_key, $exportList);
        
        $this->assign('list', $list);
        $this->assign('param',$param);
        $this->assign('_page', $_page);
        $this->assign('count', $count);

        $this->select_menu = U('Payforuser/supplier');
        $this->display();
    }
    
    //厂商代付
    public function manufacturerlier(){
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);
        
        //厂商账号
        $m_name = I('keywords', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        $start =  I('start_time', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');

        
        $start = empty($start)? date('Y-m-d',strtotime('-1 day')) : $start;

        
        
        $ctime = strtotime(date('Y-m-d 00:00:00', time()));//昨天的时间戳

        
        $c_start = $start . ' 00:00:00';
        
        $where = array();
        //起始日期
        if(strtotime($c_start)!==false){
            //只能选择昨天或者 早已昨天 否则会提示出错
            //if(strtotime($c_start) > $ctime){
                //$this->error('只能选择昨天或者之前的日期！');
            //}
            
            $where['pay_date'] = $start;
        }
        


        $param = array(
            'keywords'=>$m_name,
            'start_time'=>$start
        );
        
        session('wenjinghao_20151016_m_daifu_day', $start);
        
        $m_name = trim($m_name);
        
        if($m_name){
            $where['_string'] = "manufacturer_login_name like '%$m_name%'";
        }
        
        //厂商商家代付打款订单明细
        $m = M('manufacturer_pay_remittance_summary');
        
        

        $count = $m->where($where)->count();
        $total_price = $m->where($where)->sum('amount');
        
        $pageSize = 25;
        $Page = new \Think\Page($count,$pageSize);
        
        $offset = $Page->firstRow;

        $setpagenum = I('get.setpagenum', 20, 'intval');
        $p = I('get.p', 0, 'intval');
        
        $Page->listRows = $setpagenum;
        
        $_page = $Page->show();
 
        $list = $m->where($where)->page($p.','.$Page->listRows)->select();
        
        //总的统计
        $total_info = array(
            'count'=>$count? $count: 0,
            'total_price'=>$total_price? $total_price: 0.00,
            //'merchant_id'=>'898440342250013',
            'merchant_id'=>'000191400205189',
            'code'=>'09100',
            'date'=>date('Ymd', time())
        );

        $i = $offset+1;
        
        
        //当前页的总金额
        $current_amout_info = array_values(array_column($list, 'amount'));
        $current_amout = array_sum($current_amout_info);
        $current_amout = $current_amout? $current_amout : 0.00;
        
        //缓存要导出的数据列表
        $exportList = array(
            'queryDate'=> $start,
            'list'=>array()
        );
        
        $exportList['list'][] = array(
            'serial_number'=>'F',//收付标志或者记录序号
            'merchant_id'=>$total_info['merchant_id'],//商户ID或者列表的空列
            'date_code'=>date('Ymd', time()),//提交日期或者列表的银行代码
            'num_blank'=>count($list),//总笔数或者列表的空列
            'amout_bank_number'=>sprintf('%01.2f', $current_amout),//总金额或者列表的银行账户
            'code_unit_name'=>$total_info['code'],//业务类型或者列表的银行开户人名称
            'province'=>'',//列表的省份或者总信息的空格
            'city'=>'',//列表的城市或者总信息的空格
            'blank_one'=>'',//空格
            'blank_tow'=>'',//空格
            'amout'=>''//列表的金额或者总信息的空格
        );
        
        //查询的厂商id
        $midArr = array();

        foreach($list as $key=>$val){
            //记录序号
            $list[$key]['serial_number'] = $this->getSerialnumber($i);
            $status = $list[$key]['status']==1? '未打款' : '已打款';
            $list[$key]['status'] = $status;
            
            $midArr[] = $val['manufacturer_id'];
            $i++;
        }
        
        //要导出的数据列表
        $daochu_list = $m->where($where)->select();
        $j = 1;
        foreach($daochu_list as $data_key=>$data_val){
            //$status = $daochu_list[$data_key]['status']==1? '未打款' : '已打款';
            //$daochu_list[$data_key]['status'] = $status;

            $exportList['list'][] = array(
                'serial_number'=>$this->getSerialnumber($j),//收付标志或者记录序号
                'merchant_id'=>'',//商户ID或者列表的空列
                'date_code'=>$data_val['bank_code'],//提交日期或者列表的银行代码
                'num_blank'=>'',//总笔数或者列表的空列
                'amout_bank_number'=>$data_val['collection_bank_account'],//总金额或者列表的银行账户
                'code_unit_name'=> $data_val['collection_unit_name'],//业务类型或者列表的银行开户人名称
                'province'=>$data_val['province'],//列表的省份或者总信息的空格
                'city'=>$data_val['city'],//列表的城市或者总信息的空格
                'blank_one'=>$data_val['collection_acount_branch'],//空格
                'blank_tow'=>'',//空格
                'amout'=> $data_val['amount']//列表的金额或者总信息的空格
            );
        
            $j++;
        }
        
        
        session('wenjinghao_20151016_m_daifu_mid', $midArr);
        
        $cache_key = $this->cache_list['manufacturer_summary'];
        S($cache_key, $exportList);
        
        
        $this->assign('total_info', $total_info);
        $this->assign('list', $list);
        $this->assign('param',$param);
        $this->assign('_page', $_page);
        $this->assign('currentDay', $start);
        $this->select_menu = U('Payforuser/manufacturerlier');
        $this->display();
    }
    
    //厂商明细
    public function manufacturerDetail(){
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);
        
        //厂商账号或者经销商账号
        $m_name = I('keywords', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        $start =  I('start_time', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        $end =  I('end_time', '', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        $status = I('status', '0', 'stripslashes,htmlentities,htmlspecialchars,strip_tags');
        
        $start = empty($start)? date('Y-m-d',strtotime('-1 day')) : $start;
        $end = empty($end)? date('Y-m-d',strtotime('-1 day')) : $end;
        
        
        $ctime = strtotime(date('Y-m-d 00:00:00', time()));//昨天的时间戳
        $my_start = date('Y-m-d 00:00:00', time());
        $my_end = date('Y-m-d 23:59:59', time());
        
        //查询条件
        $where = array();
        
        $c_start = $start . ' 00:00:00';
        $c_end = $end . ' 23:59:59';
        
        //起始日期
        if(strtotime($c_start)!==false){
            //只能选择昨天或者 早已昨天 否则会提示出错
            //if(strtotime($c_start) > $ctime){
                //$this->error('只能选择昨天或者之前的日期！');
            //}
        
            $my_start = date('Y-m-d 00:00:00', strtotime($start));
            $where['pay_time'][] = array('egt', $my_start);
        }
        
        if(strtotime($c_start)> strtotime($c_end)){
            $this->error('起始日期不能大于截止日期！');
        }
        
        //结束日期
        if(strtotime($c_end)!==false){
            //只能选择昨天或者 早已昨天 否则会提示出错
            //if(strtotime($c_end) > $ctime){
               // $this->error('只能选择昨天或者之前的日期！');
            //}
        
            $my_end = date('Y-m-d 23:59:59', strtotime($end));
            $where['pay_time'][] = array('elt', $my_end);
        }
        
        $param = array(
            'keywords'=>$m_name,
            'start_time'=>$start,
            'end_time'=>$end,
            'status'=>$status
        );
        
        //验证开始日期和结束日期的时间间隔不能超过90天
        $endTime = strtotime($my_end);
        $startTime = strtotime($my_start);
        $intervalDay = ceil(($endTime-$startTime)/86400);
        
        if($intervalDay>90){
            $this->error('查询的时间段不能超过90天');
        }
        
        $m_name = trim($m_name);
        
        if($m_name){
            //$sql_where .= "m_name like '%$m_name%' and ";
            $where['_string'] = "manufacturer_name like '%$m_name%' OR order_sn like '%$m_name%'";
        }
        
        if($status){
            $where['status'] = $status;
        }

       //获取厂商订单的明细
       $list = array();
       $m = M('manufacturer_order_pay_remittance_detail');
       $my_field = array(
           'pay_time',
           'order_sn',
           'order_type',
           'pay_price',
           'manufacturer_login_name',
           'manufacturer_name',
           'supplier_login_name',
           'supplier_name',
           'status'
       );
       
        $count = $list = $m->where($where)->count();
        
        $pageSize = 50;
        $Page = new \Think\Page($count,$pageSize);
        
        $offset = $Page->firstRow;
        
        $setpagenum = I('get.setpagenum', 50, 'intval');
        $p = I('get.p', 0, 'intval');
        
        $Page->listRows = $setpagenum;
        
        $_page = $Page->show();
        
        $list = $m->where($where)->field($my_field)->order('pay_time desc')->page($p.','.$Page->listRows)->select();
        
        //缓存要导出的数据列表
        $exportList = array(
            'queryDate'=> '('.substr($start,0,10) . '~' . substr($end,0,10).')',
            'list'=>array()
        );
        
        foreach($list as $key=>$val){
            $list[$key]['pay_time'] = substr($val['pay_time'],0,10);
            
            $status = $list[$key]['status']==1? '未打款' : '已打款';
            $list[$key]['status'] = $status;
        }
        
        //要导出的数据列表
        $daochu_list = $m->where($where)->field($my_field)->order('pay_time desc')->select();
        foreach($daochu_list as $data_key=>$data_val){
            $exportList['list'][] = array(
                'pay_date' => substr($data_val['pay_time'],0,10),
                'm_name' => $data_val['manufacturer_login_name'],
                'manufacturer_name'=>$data_val['manufacturer_name'],
                's_name' => $data_val['supplier_login_name'],
                'supplier_name' => $data_val['supplier_name'],
                'order_sn'=>$data_val['order_sn'],
                'order_type' =>$this->m_order_type[$data_val['order_type']],
                //'pay_method' => '支付方式',
                'order_amount'=>$data_val['pay_price'],
                'factorage_amount'=>$data_val['factorage'],
                'transfer_amount'=>$data_val['pay_price']-$data_val['factorage'],
                'status'=>$data_val['status']==1? '未打款' : '已打款'
            );
        }
        
        
        $cache_key = $this->cache_list['manufacturer_detail'];
        S($cache_key, $exportList);
        
        $this->assign('list', $list);
        $this->assign('param',$param);
        $this->assign('_page', $_page);
        $this->assign('count', $count);
        $this->select_menu = U('Payforuser/manufacturerlier');
        $this->display();
    }
    
    //ajax修改厂商代付的打款状态
    public function updateStatus(){
        $status = I('post.status');
        $midStr = I('post.mid');
        $day = I('post.day');
        
        //经销商id
        $midArr = explode('-', $midStr);
        //检验状态值
        $legal_status = array(1,2);
        if(!in_array($status, $legal_status)){
            $this->echoJson('-1', '传递的状态参数异常！');
        }
        
        //检测时间是否合法
        $legal_day = session('wenjinghao_20151016_m_daifu_day');
        if($day!= $legal_day){
            $this->echoJson('-2', '传递的时间参数异常！');
        }
        
        
        //过滤非法的mid
        $legal_mid = session('wenjinghao_20151016_m_daifu_mid');
        $real_mid_arr = array_intersect($midArr,$legal_mid);
        
        if(empty($real_mid_arr)){
            $this->echoJson('-3', '传递的参数异常！');
        }
        
        
        $remittance_summary = M('manufacturer_pay_remittance_summary');
        $remittance_detail = M('manufacturer_order_pay_remittance_detail');
        
        $remittance_summary_log = M('order_remittance_status_log');
        
        //检查是否有符合状态的数据
        if($status==1){//要变更为：未付款， 要检查是否有：已付款
            $count_status = 2;
        }else{//要变更为：已付款， 要检查是否有：未付款
            $count_status = 1;
        }
        $count_where= array(
            'manufacturer_id'=>array('in', array_values($real_mid_arr)),
            'pay_date'=>$day,
            'status'=>$count_status
        );
        $status_count = $remittance_summary->where($count_where)->count();
        if($status_count==0){
            $this->echoJson('-3', '没有符合状态变更的数据！');
        }
        
        $detail_updateData = array(
            'status'=>intval($status),
            'updated'=>date('Y-m-d H:i:s', time())
        );
        
        $summary_updateData = array(
            'status'=>intval($status),
            'updated'=>date('Y-m-d H:i:s', time())
        );
        
        //如果是打款状态
        if(intval($status) == 2){
            $summary_updateData['remittance_time'] = date('Y-m-d H:i:s', time());
            $detail_updateData['remittance_time'] = date('Y-m-d H:i:s', time());
        }
        
        
        //修改汇总的打款状态
        $start = $day . ' 00:00:00';
        $end = $day . ' 23:59:59';
        
        foreach($real_mid_arr as $key=>$val){
             $where= array(
                'manufacturer_id'=>$val,
                'pay_date'=>$day
            );
             
            $res = $remittance_summary->where($where)->save($summary_updateData);
            
            $summary_log_data = array(
                'user_id'=>$val,
                'pay_date'=>$day,
                'update_status'=>$status,
                'type'=>1,//1 厂商代付 2 经销商代付
                'log'=>1, //1 汇总日志 2 明细日志
                'addtime'=>date('Y-m-d H:i:s', time())
            );

            if($res){
                $summary_log_data['msg'] = '成功';
                $remittance_summary_log->data($summary_log_data)->add();
                //修改订单的打款状态
                $order_where = array('manufacturer_id'=>$val);
                $order_where['pay_time'][] = array('egt', $start);
                $order_where['pay_time'][] = array('elt', $end);
                
                $order_res = $remittance_detail->where($order_where)->save($detail_updateData);
                
                //把补单的也修改为 ：相应的打款状态
                $budan_remittance_detail_model = M('budan_manufacturer_order_pay_remittance_detail');
                $budan_remittance_detail_model->where($order_where)->save($detail_updateData);

                $summary_detail_data = array(
                    'user_id'=>$val,
                    'pay_date'=>$day,
                    'update_status'=>$status,
                    'type'=>1,//1 厂商代付 2 经销商代付
                    'log'=>2, //1 汇总日志 2 明细日志
                    'addtime'=>date('Y-m-d H:i:s', time())
                );
                
                if(empty($order_res)){
                    $summary_detail_data['msg'] = '失败';
                    $remittance_summary_log->data($summary_detail_data)->add();
                   $this->echoJson('-2', '很抱歉，网络繁忙！');
                }else{
                    $summary_detail_data['msg'] = '成功';
                    $remittance_summary_log->data($summary_detail_data)->add();
                }
            }else{
                $summary_log_data['msg'] = '失败';
                $remittance_summary_log->data($summary_log_data)->add();
                $this->echoJson('-2', '很抱歉，网络繁忙！');
            }
        }
        
        $this->echoJson('0', '修改状态成功!');
    }
    
    //ajax修改经销商代付的打款状态
    public function updateSupplierPayStatus(){
        $status = I('post.status');
        $sidStr = I('post.sid', '');
        $day = I('post.day');
    
        //经销商id
        if(empty($sidStr)){
            $this->echoJson('-3', '传递的参数异常！');
        }
        $sidArr = explode('-', $sidStr);
        //检验状态值
        $legal_status = array(1,2);
        if(!in_array($status, $legal_status)){
            $this->echoJson('-1', '传递的状态参数异常！');
        }
    
        //检测时间是否合法
        $legal_day = session('wenjinghao_20151017_s_daifu_day');
        if($day!= $legal_day){
            $this->echoJson('-2', '传递的时间参数异常！');
        }
    
    
        //过滤非法的经销商id
        $legal_sid = session('wenjinghao_20151017_s_daifu_sid');
        $real_sid_arr = array_intersect($sidArr,$legal_sid);
        
        if(empty($real_sid_arr)){
            $this->echoJson('-3', '传递的参数异常！');
        }
        

        $remittance_summary = M('supplier_pay_remittance_summary');
        $remittance_detail = M('supplier_order_pay_remittance_detail');
        
        $remittance_summary_log = M('order_remittance_status_log');
        
        //检查是否有符合状态的数据
        if($status==1){//要变更为：未付款， 要检查是否有：已付款
            $count_status = 2;
        }else{//要变更为：已付款， 要检查是否有：未付款
            $count_status = 1;
        }
        $count_where= array(
            'supplier_id'=>array('in', array_values($real_sid_arr)),
            'pay_date'=>$day,
            'status'=>$count_status
        );
        $status_count = $remittance_summary->where($count_where)->count();
        if($status_count==0){
            $this->echoJson('-3', '没有符合状态变更的数据！');
        }
    
        $detail_updateData = array(
            'status'=>intval($status),
            'updated'=>date('Y-m-d H:i:s', time())
        );
        
        $summary_updateData = array(
            'status'=>intval($status),
            'updated'=>date('Y-m-d H:i:s', time())
        );

        //如果是打款状态
        if(intval($status) == 2){
            $summary_updateData['remittance_time'] = date('Y-m-d H:i:s', time());
            $detail_updateData['remittance_time'] = date('Y-m-d H:i:s', time());
        }
        
        //修改汇总的打款状态
        $start = $day . ' 00:00:00';
        $end = $day . ' 23:59:59';
    
        foreach($real_sid_arr as $key=>$val){
            $where= array(
                'supplier_id'=>$val,
                'pay_date'=>$day
            );
            
            $res = $remittance_summary->where($where)->save($summary_updateData);
    
            $summary_log_data = array(
                'user_id'=>$val,
                'pay_date'=>$day,
                'update_status'=>$status,
                'type'=>2,//1 厂商代付 2 经销商代付
                'log'=>1, //1 汇总日志 2 明细日志
                'addtime'=>date('Y-m-d H:i:s', time())
            );
    
            if($res){
                $summary_log_data['msg'] = '成功';
                $remittance_summary_log->data($summary_log_data)->add();
                //修改订单的打款状态
                $order_where = array('supplier_id'=>$val);
                $order_where['pay_time'][] = array('egt', $start);
                $order_where['pay_time'][] = array('elt', $end);
    
                $order_res = $remittance_detail->where($order_where)->save($detail_updateData);
                
                //把补单的也修改为 ：相应的打款状态
                $budan_remittance_detail_model = M('budan_supplier_order_pay_remittance_detail');
                $budan_remittance_detail_model->where($order_where)->save($detail_updateData);
    
                $summary_detail_data = array(
                    'user_id'=>$val,
                    'pay_date'=>$day,
                    'update_status'=>$status,
                    'type'=>2,//1 厂商代付 2 经销商代付
                    'log'=>2, //1 汇总日志 2 明细日志
                    'addtime'=>date('Y-m-d H:i:s', time())
                );
    
                if(empty($order_res)){
                    $summary_detail_data['msg'] = '失败';
                    $remittance_summary_log->data($summary_detail_data)->add();
                    $this->echoJson('-2', '很抱歉，网络繁忙！');
                }else{
                    $summary_detail_data['msg'] = '成功';
                    $remittance_summary_log->data($summary_detail_data)->add();
                }
            }else{
                $summary_log_data['msg'] = '失败';
                $remittance_summary_log->data($summary_log_data)->add();
                $this->echoJson('-2', '很抱歉，网络繁忙！');
            }
        }
    
        $this->echoJson('0', '修改状态成功!');
    }
    
    //导出报表
    public function exportTradelist(){
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);
        
        $export_flag = I('flag');
        $cache_key = $this->cache_list[$export_flag];
        $list = S($cache_key);
        
        $query_date = $list['queryDate'];
        $export_data = $list['list'];
        
        if(in_array($export_flag,array('supplier_detail','supplier_summary','manufacturer_detail','manufacturer_summary'))) {
            switch($export_flag) {
                case 'supplier_detail': //经销商代付明细列表
                    $data_title = array(
                        'pay_date' => '支付日期',
                        'supplier_login_name' => '经销商账号',
                        'supplier_name'=>'经销商名称',
                        'user_login_name' => '零售店账号',
                        'user_name' => '名称',
                        'order_sn'=>'订单号',
                        'order_type' => '订单类型',
                        'pay_method' => '支付方式',
                        'order_amount'=>'订单金额(元)',
                        'factorage_amount'=>'手续费(元)',
                        'transfer_amount'=>'代付金额(元)'
                    );
                    
                        //经销商代付明细列表
                        exportExcel($export_data, $data_title, 's_detail_'.$query_date);
                        break;
                case 'manufacturer_detail': //厂商代付明细列表
                    $data_title = array(
                        'pay_date' => '支付日期',
                        'm_name' => '厂商账号',
                        'manufacturer_name'=>'厂商名称',
                        's_name' => '经销商账号',
                        'supplier_name' => '经销商名称',
                        'order_sn'=>'订单号',
                        'order_type' => '订单类型',
                        //'pay_method' => '支付方式',
                        'order_amount'=>'结算金额(元)',
                        'factorage_amount'=>'手续费(元)',
                        'transfer_amount'=>'代付金额(元)',
                        'status'=>'打款状态'
                      );
                       //厂商代付明细列表
                       exportExcel($export_data,$data_title, 'm_detail_'.$query_date);
                        break;
                case 'supplier_summary': //经销商代付汇总
                    $data_title=array(
                        'serial_number'=>'',//收付标志或者记录序号
                        'merchant_id'=>'',//商户ID或者列表的空列
                        'date_code'=>'',//提交日期或者列表的银行代码
                        'num_blank'=>'',//总笔数或者列表的空列
                        'amout_bank_number'=>'',//总金额或者列表的银行账户
                        'code_unit_name'=>'',//业务类型或者列表的银行开户人名称
                        'province'=>'',//列表的省份或者总信息的空格
                        'city'=>'',//列表的城市或者总信息的空格
                        'blank_one'=>'',//空格
                        'blank_tow'=>'',//空格
                        'amout'=>''//列表的城市或者总信息的空格
                    );
                    //经销商付款汇总
                    $file_name = '000191400205187_F03' . date('Ymd', time()) . '_F0001';
                    exportNoTitleExcel($export_data,$data_title, $file_name);
                    break;
                    case 'manufacturer_summary': //厂商代付汇总
                       $data_title=array(
                        'serial_number'=>'',//收付标志或者记录序号
                        'merchant_id'=>'',//商户ID或者列表的空列
                        'date_code'=>'',//提交日期或者列表的银行代码
                        'num_blank'=>'',//总笔数或者列表的空列
                        'amout_bank_number'=>'',//总金额或者列表的银行账户
                        'code_unit_name'=>'',//业务类型或者列表的银行开户人名称
                        'province'=>'',//列表的省份或者总信息的空格
                        'city'=>'',//列表的城市或者总信息的空格
                        'blank_one'=>'',//空格
                        'blank_tow'=>'',//空格
                        'amout'=>''//列表的城市或者总信息的空格
                       );
                        //厂商代付汇总
                        $file_name = '000191400205189_F03' . date('Ymd', time()) . '_F0001';
                        exportNoTitleExcel($export_data,$data_title, $file_name);
                        break;
            }
        }
        exit;
    }
    
    //代付汇总的报表导出 选择需要导出的条目进行导出
    public function newExportTradelist(){
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);
        
        $serialIds = I('get.serialIds', '');
        $serialArr = explode('-', $serialIds);
        //$export_flag = 'manufacturer_summary'; supplier_summary
        $export_flag = I('flag');

        $cache_key = $this->cache_list[$export_flag];
        $list = S($cache_key);
        $query_date = $list['queryDate'];
        $export_data = $list['list'];
        
        if(empty($export_data)){
            $this->error('网络出现异常，请重新查询导出！');
        }
        
        //厂商
        if($export_flag ==  'manufacturer_summary'){
            $data_title=array(
                'serial_number'=>'',//收付标志或者记录序号
                'merchant_id'=>'',//商户ID或者列表的空列
                'date_code'=>'',//提交日期或者列表的银行代码
                'num_blank'=>'',//总笔数或者列表的空列
                'amout_bank_number'=>'',//总金额或者列表的银行账户
                'code_unit_name'=>'',//业务类型或者列表的银行开户人名称
                'province'=>'',//列表的省份或者总信息的空格
                'city'=>'',//列表的城市或者总信息的空格
                'blank_one'=>'',//空格
                'blank_tow'=>'',//空格
                'amout'=>''//列表的城市或者总信息的空格
            );
            $file_name = '000191400205189_F03' . date('Ymd', time()) . '_F' . date('is', time());
        }
        
        //经销商
        if($export_flag ==  'supplier_summary'){
            $data_title=array(
                'serial_number'=>'',//收付标志或者记录序号
                'merchant_id'=>'',//商户ID或者列表的空列
                'date_code'=>'',//提交日期或者列表的银行代码
                'num_blank'=>'',//总笔数或者列表的空列
                'amout_bank_number'=>'',//总金额或者列表的银行账户
                'code_unit_name'=>'',//业务类型或者列表的银行开户人名称
                'province'=>'',//列表的省份或者总信息的空格
                'city'=>'',//列表的城市或者总信息的空格
                'blank_one'=>'',//空格
                'blank_tow'=>'',//空格
                'amout'=>''//列表的城市或者总信息的空格
            );
            $file_name = '000191400205187_F03' . date('Ymd', time()) . '_F'. date('is', time());
        }
        
        if($export_flag ==  'supplier_summary' || $export_flag == 'manufacturer_summary'){
            if(empty($serialIds)){
                exportNoTitleExcel($export_data,$data_title, $file_name);
                exit;
            }
            //dump($serialArr);
            //exit;
            if($serialArr){
                $new_data = array();
                $new_data[] = $export_data[0];
                unset($export_data[0]);
                $total_amout = 0.00;
                $i = 1;
                $number = '';
                foreach($export_data as $key=>$val){
                    $number = $val['serial_number'];
                    if(in_array($number, $serialArr)){
                        $number = $this->getSerialnumber($i);
                        $export_data[$key]['serial_number'] = $number;
                        $new_data[] = $export_data[$key];
                        $total_amout += $export_data[$key]['amout']-$export_data[$key]['factorage'];
                        $i++;
                    }
                }
            
                $new_data[0]['amout_bank_number'] = $total_amout;
                $new_data[0]['num_blank'] = count($new_data)-1;
            
                exportNoTitleExcel($new_data,$data_title, $file_name);
            }
            exit;
        }
    }
    /**
     * 根据地区编码获取地区信息
     * @param int $areaSn
     * @return arr $areaNameArr
     */
    public function getProvinceAndCityByArea($areaSn,$bObj){
        $areaNameArr = array();
        //地区id非法处理
        if(!is_numeric($areaSn)){
            return $areaNameArr;
        }
        
        $key = 'wenjinghhao-sheng-shi-areaName-arr-' . $areaSn;

        //是否命中缓存
        if(S($key)){
            $areaNameArr = S($key);
            return $areaNameArr;
        }else{
            $areaNameArr = $bObj->getAreaNameListBySn($areaSn);
            S($key, $areaNameArr);
            return $areaNameArr;
        }
        return $areaNameArr;
    }
    
    
    /**
     * @param number $amount 订单金额
     * @param number $pay_method 支付方式  1 在线  2 pos
     * @return number $fee 手续费
     * POS支付3000元以下订单每笔收取0.7%手续费，3000元以上订单每笔收取26元手续费。
     * 计算手续费 在线支付方式每笔收取0.7%手续费；  $pay_method=1 在线  2 pos
     */
    public function getBankServicefee($amount=0, $pay_method=1){
        $fee = 0.00;
        //验证金额
        if(!is_numeric($amount) || $amount<=0){
            return $fee;
        }
    
        //验证支付方式
        if(!in_array($pay_method, array(1,2))){
            return $fee;
        }
        
        $pay_method = intval($pay_method);
    
        switch($pay_method) {
            case 1:  //在线支付
                $fee = round($amount*0.007, 2);
                break;
            case 2: //pos支付
                if($amount>=3000){
                    $fee = 26.00;
                }else{
                    $fee = round($amount*0.007, 2);
                }
                break;
        }
        return $fee;
    }
    
    
    //获取代付记录序号
    public function getSerialnumber($num){
        $serialnumber = str_pad(strval($num), 6, '0', STR_PAD_LEFT);
        return substr($serialnumber,-6);
    }
    
    //ajax输出信息
    public function echoJson($code,$msg){
        echo json_encode(array("code"=>$code, "msg"=>$msg));
        exit;
    }
    
    //获取网点名称 $type=1 经销商  2 厂商
    public function getTransferbankName($uid, $type=1){
        $res_str = '';
        if($uid){
           if($type==1){
               $model = M('supplier_info');//transfer_bank_a  supplier_id
               $where = array('supplier_id'=>$uid);
               $res_str = $model->where($where)->getField('transfer_bank_a');
           }
           
          if($type==2){
              $model = M('manufacturer_info'); //manufacturer_id collection_acount_branch
              $where = array('manufacturer_id'=>$uid);
              $res_str = $model->where($where)->getField('collection_acount_branch');
           }
        }
        
        return $res_str;
    }
}
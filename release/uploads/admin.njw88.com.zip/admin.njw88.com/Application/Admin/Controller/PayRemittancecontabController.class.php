<?php
/*
 * 订单代付的任务定时器
 */
namespace Admin\Controller;
use  Think\Controller;
class PayRemittancecontabController extends Controller{
    //经销商代付每天任务
    public function supplier(){
    	
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);
        
        $start = date('Y-m-d 00:00:00', strtotime('-1 day'));
        $end = date('Y-m-d 23:59:59', strtotime('-1 day'));
        
        //检查是否已经执行过
        $this->isOperted(2);
        
        $m = M();
        //普通订单  过滤掉自营订单
        $pt_sql = "select A.order_sn,A.pay_price,0 as order_type, A.pay as pay_method,A.end_time as pay_time,G.create_time as create_order_time,
                            A.user_id,E.name as user_login_name, B.user_name,C.supplier_id,F.name as supplier_login_name,
                            D.supplier_name,D.transfer_account,
                            D.transfer_name,D.transfer_area,D.transfer_bank_n,
                            D.transfer_bank_a,D.bank_code 
                            from b2b_order_pay as A 
                            left join b2b_order as G ON G.order_sn = A.order_sn
                            left join b2b_user_info as B on B.user_id=A.user_id
                            left join b2b_user as E ON B.user_id=E.id
                            left join b2b_user_salesman_supplier C on C.user_id=B.user_id
                            left join b2b_supplier_info as D on D.supplier_id = C.supplier_id
                            left join b2b_supplier as F ON D.supplier_id =F.id
                            where G.autotrophic=0 and A.status='2' and A.end_time >='{$start}' and A.end_time<='{$end}' group by A.order_sn";
        $this->addRemittanceListBySql($pt_sql, 1);

        //预付款
        $yf_sql = "select A.order_sn,A.pay_amount as pay_price,3 as order_type, A.pay_method-1 as pay_method,A.payment_time as pay_time,H.created as create_order_time,
                            B.user_id,E.name as user_login_name, B.user_name,D.supplier_id,F.name as supplier_login_name,
                            D.supplier_name,D.transfer_account,
                            D.transfer_name,D.transfer_area,D.transfer_bank_n,
                            D.transfer_bank_a,D.bank_code
                            from b2b_njw_gold_order_pay as A
                            left join b2b_njw_gold_order as H ON H.order_sn=A.order_sn
                            left join b2b_user_info as B on A.user_id=B.user_id
                            left join b2b_user as E on E.id = B.user_id
                            left join b2b_user_salesman_supplier as G ON B.user_id=G.user_id
                            left join b2b_supplier_info as D on G.supplier_id = D.supplier_id
                            left join b2b_supplier as F ON D.supplier_id=F.id
                            where A.payment_status=2 and A.payment_time>='{$start}' and A.payment_time<='{$end}' group by A.order_sn";
        $this->addRemittanceListBySql($yf_sql, 1);
        
        //回款订单
        $hk_sql = "select A.tally_order_sn as order_sn,A.pay_amount as pay_price,2 as order_type, A.pay_method-1 as pay_method,A.end_time as pay_time,H.created as create_order_time,
                            B.user_id,E.name as user_login_name, B.user_name,D.supplier_id,F.name as supplier_login_name,
                            D.supplier_name,D.transfer_account,
                            D.transfer_name,D.transfer_area,D.transfer_bank_n,
                            D.transfer_bank_a,D.bank_code
                            from b2b_credit_tally_order_pay as A
                            left join b2b_credit_tally_order as H ON H.order_sn=A.tally_order_sn
                            left join b2b_user_info as B on B.user_id=H.user_id
                            left join b2b_user as E on E.id = B.user_id
                            left join b2b_supplier_info as D on D.supplier_id = H.supplier_id
                            left join b2b_supplier as F ON F.id=D.supplier_id
                            where A.status=2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.tally_order_sn";
        $this->addRemittanceListBySql($hk_sql, 1);
        
        
        //保证金
        $bz_sql = "select A.apply_sn as order_sn,A.pay_amount as pay_price,4 as order_type, A.pay_method-1 as pay_method,A.end_time as pay_time,G.apply_times as create_order_time,
                            B.user_id,E.name as user_login_name, B.user_name,A.supplier_id,F.name as supplier_login_name,
                            D.supplier_name,D.transfer_account,
                            D.transfer_name,D.transfer_area,D.transfer_bank_n,
                            D.transfer_bank_a,D.bank_code
                            from b2b_credit_apply_pay_log as A
                            left join b2b_credit_apply_record as G ON G.apply_sn=A.apply_sn
                            left join b2b_user_info as B on B.user_id=A.payment_user_id
                            left join b2b_user as E on E.id = A.payment_user_id
                            left join b2b_supplier_info as D on D.supplier_id = A.supplier_id
                            left join b2b_supplier as F ON F.id=A.supplier_id
                            where A.pay_status=2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.apply_sn";
        $this->addRemittanceListBySql($bz_sql, 1);
        
        
        /******经销商代付汇总昨天的*******/
        $sql = "select supplier_login_name,supplier_name,bank_code,transfer_account,transfer_name,province,city,sum(pay_price) as amount,sum(factorage) as factorage,supplier_id,DATE_FORMAT(pay_time,'%Y-%m-%d') as pay_date
                        from b2b_supplier_order_pay_remittance_detail
                        where pay_time>='{$start}' and pay_time<='{$end}' group by supplier_id,pay_date";

        //汇总信息
        $remittance_summary_model = M('supplier_pay_remittance_summary');
        $remittance_summary_arr = $m->query($sql);
        
        if($remittance_summary_arr){
            $where = array();
            $current_info = array();
            $current_amount = 0.00;
            $new_amount = 0.00;
            $update_data = array();
        
            foreach($remittance_summary_arr as $mpaykey=>$cData){
                if($cData['supplier_id']){
                    $where = array(
                        'supplier_id'=>$cData['supplier_id'],
                        'pay_date'=>$cData['pay_date']
                    );
                    $current_info = $remittance_summary_model->where($where)->find();
                    if($current_info){
                        $new_amount = $cData['amount'];
                        $update_data = array(
                            'amount'=>$new_amount,
                        	'factorage'=>$cData['factorage'],
                            'updated'=>date('Y-m-d H:i:s', time())
                        );
                        $update_res = $remittance_summary_model->where($where)->save($update_data);
                        if($update_res===false){
                            $data = array(
                                'op_sql'=> $remittance_summary_model->_sql(),
                                'err_tip'=>$remittance_summary_model->getDbError(),
                                'err_order_sn'=>'空',
                                'err_msg'=>'修改经销商代付汇总的金额时失败',
                                'add_time'=>date('Y-m-d H:i:s', time())
                            );
                            $this->addTabLog($data);
                        }
                    }else{
                        if(empty($current_info) && $current_info!==false){
                            $insert_res = $remittance_summary_model->data($cData)->add();
                            if($insert_res===false){
                                $data = array(
                                    'op_sql'=> $remittance_summary_model->_sql(),
                                    'err_tip'=>$remittance_summary_model->getDbError(),
                                    'err_order_sn'=>'空',
                                    'err_msg'=>'新增经销商代付汇总时失败',
                                    'add_time'=>date('Y-m-d H:i:s', time())
                                );
                                $this->addTabLog($data);
                            }
                        }
                        if($current_info === false){
                            $data = array(
                                'op_sql'=> $remittance_summary_model->_sql(),
                                'err_tip'=>$remittance_summary_model->getDbError(),
                                'err_order_sn'=>'空',
                                'err_msg'=>'查询是否存在经销商代付汇总时失败',
                                'add_time'=>date('Y-m-d H:i:s', time())
                            );
                            $this->addTabLog($data);
                        }
                    }
                }
            }
        }else{
            if($remittance_summary_arr === false){
                $data = array(
                    'op_sql'=>$sql,
                    'err_tip'=>$m->getDbError(),
                    'err_order_sn'=>'空',
                    'err_msg'=>'查询并统计:经销商代付明细的汇总时失败',
                    'add_time'=>date('Y-m-d H:i:s', time())
                );
                $this->addTabLog($data);
            }
        }
    }
    //厂商代付每天任务
    public function manufacturer(){
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);
        
        $start = date('Y-m-d 00:00:00', strtotime('-1 day'));
        $end = date('Y-m-d 23:59:59', strtotime('-1 day'));
        
        //检查是否已经执行过
        $this->isOperted(3);
        
        $m = M();
        
        //厂商订单
        $supplier_order_sql = "select C.m_id as manufacturer_id,C.supplier_id,F.user_name as manufacturer_login_name,D.manufacturer_name,D.bank_code,D.collection_acount_branch,D.collection_bank_account,
                                        D.collection_unit_name,D.open_bank_area,E.supplier_name,G.name as supplier_login_name,
                                        A.order_sn,C.settlement_price as pay_price,6 as order_type, A.pay as pay_method,A.end_time as pay_time,C.create_time as create_order_time
                                        from b2b_supplier_order_pay as A
                                        left join b2b_supplier_order as C on C.order_sn = A.order_sn
                                        left join b2b_manufacturer_info as D on D.manufacturer_id = C.m_id
                                        left join b2b_manufacturer as F on F.id = D.manufacturer_id
                                        left join b2b_supplier_info as E on E.supplier_id = C.supplier_id
                                        left join b2b_supplier as G on G.id = E.supplier_id
                                        where A.status='2' and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.order_sn";
        $this->addRemittanceListBySql($supplier_order_sql, 2);
        

        /**********厂商代付汇总 昨天的**************/
        $sel_feild = "manufacturer_login_name,manufacturer_name,bank_code,collection_acount_branch,collection_bank_account,
                      collection_unit_name,province,city,sum(pay_price) as amount,manufacturer_id,DATE_FORMAT(pay_time,'%Y-%m-%d') as pay_date ";
        //$ins_feild = "manufacturer_login_name,manufacturer_name,bank_code,collection_acount_branch,collection_bank_account,collection_unit_name,province,city,amount,manufacturer_id,pay_date";
        $sql = "select ".$sel_feild."from b2b_manufacturer_order_pay_remittance_detail where pay_time>='{$start}' and pay_time<='{$end}' group by manufacturer_id,pay_date";
        
        //汇总信息
        $remittance_summary_model = M('manufacturer_pay_remittance_summary');
        $remittance_summary_arr = $m->query($sql);
        
        if($remittance_summary_arr){
              $where = array();
              $current_info = array();
              $current_amount = 0.00;
              $new_amount = 0.00;
              $update_data = array();
              
              foreach($remittance_summary_arr as $mpaykey=>$cData){
                  if($cData['manufacturer_id']){
                      $where = array(
                          'manufacturer_id'=>$cData['manufacturer_id'],
                          'pay_date'=>$cData['pay_date']
                      );
                      $current_info = $remittance_summary_model->where($where)->find();
                      if($current_info){
                          $new_amount = $cData['amount'];
                          $update_data = array(
                              'amount'=>$new_amount,
                              'updated'=>date('Y-m-d H:i:s', time())
                          );
                          $update_res = $remittance_summary_model->where($where)->save($update_data);
                          if($update_res===false){
                              $data = array(
                                  'op_sql'=> $remittance_summary_model->_sql(),
                                  'err_tip'=>$remittance_summary_model->getDbError(),
                                  'err_order_sn'=>'空',
                                  'err_msg'=>'修改厂商代付汇总的汇总金额时失败',
                                  'add_time'=>date('Y-m-d H:i:s', time())
                              );
                              $this->addTabLog($data);
                          }
                      }else{
                          if(empty($current_info) && $current_info!==false){
                              $insert_res = $remittance_summary_model->data($cData)->add();
                              if($insert_res===false){
                                  $data = array(
                                      'op_sql'=> $remittance_summary_model->_sql(),
                                      'err_tip'=>$remittance_summary_model->getDbError(),
                                      'err_order_sn'=>'空',
                                      'err_msg'=>'新增厂商代付汇总时失败',
                                      'add_time'=>date('Y-m-d H:i:s', time())
                                  );
                                  $this->addTabLog($data);
                              }
                          }
                          if($current_info === false){
                              $data = array(
                                  'op_sql'=> $remittance_summary_model->_sql(),
                                  'err_tip'=>$remittance_summary_model->getDbError(),
                                  'err_order_sn'=>'空',
                                  'err_msg'=>'查询是否存在厂商代付汇总时失败',
                                  'add_time'=>date('Y-m-d H:i:s', time())
                              );
                              $this->addTabLog($data);
                          }
                      }
                  }
              }
        }else{
           if($remittance_summary_arr === false){
               $data = array(
                   'op_sql'=>$sql,
                   'err_tip'=>$m->getDbError(),
                   'err_order_sn'=>'空',
                   'err_msg'=>'查询并统计:厂商代付明细时失败',
                   'add_time'=>date('Y-m-d H:i:s', time())
               );
               $this->addTabLog($data);
           }
        }
    }
    //经销商截止昨天的
    public function yestodaySupplier8118(){
//         //exit;
//         //设置php的内存不限制
//         ini_set('memory_limit',-1);
//         //设置php运行时间不限制
//         ini_set("max_execution_time", 0);
//         $start = date('Y-m-d 00:00:00', time());
        
//         $m = M();
//         //普通订单
//         $pt_sql = "select A.order_sn,A.pay_price,0 as order_type, A.pay as pay_method,A.end_time as pay_time,G.create_time as create_order_time,
//                             A.user_id,E.name as user_login_name, B.user_name,C.supplier_id,F.name as supplier_login_name,
//                             D.supplier_name,D.transfer_account,
//                             D.transfer_name,D.transfer_area,D.transfer_bank_n,
//                             D.transfer_bank_a,D.bank_code
//                             from b2b_order_pay as A
//                             left join b2b_order as G ON G.order_sn = A.order_sn
//                             left join b2b_user_info as B on B.user_id=A.user_id
//                             left join b2b_user as E ON B.user_id=E.id
//                             left join b2b_user_salesman_supplier C on C.user_id=B.user_id
//                             left join b2b_supplier_info as D on D.supplier_id = C.supplier_id
//                             left join b2b_supplier as F ON D.supplier_id =F.id
//                             where A.status='2' and A.end_time<'{$start}' group by A.order_sn";
//         $this->addRemittanceListBySql($pt_sql, 1);
        
//         //预付款
//         $yf_sql = "select A.order_sn,A.pay_amount as pay_price,3 as order_type, A.pay_method-1 as pay_method,A.payment_time as pay_time,H.created as create_order_time,
//                             B.user_id,E.name as user_login_name, B.user_name,D.supplier_id,F.name as supplier_login_name,
//                             D.supplier_name,D.transfer_account,
//                             D.transfer_name,D.transfer_area,D.transfer_bank_n,
//                             D.transfer_bank_a,D.bank_code
//                             from b2b_njw_gold_order_pay as A
//                             left join b2b_njw_gold_order as H ON H.order_sn=A.order_sn
//                             left join b2b_user_info as B on A.user_id=B.user_id
//                             left join b2b_user as E on E.id = B.user_id
//                             left join b2b_user_salesman_supplier as G ON B.user_id=G.user_id
//                             left join b2b_supplier_info as D on G.supplier_id = D.supplier_id
//                             left join b2b_supplier as F ON D.supplier_id=F.id
//                             where A.payment_status=2 and A.payment_time<'{$start}' group by A.order_sn";
//         $this->addRemittanceListBySql($yf_sql, 1);
        
//         //回款订单
//         $hk_sql = "select A.tally_order_sn as order_sn,A.pay_amount as pay_price,2 as order_type, A.pay_method-1 as pay_method,A.end_time as pay_time,H.created as create_order_time,
//                             B.user_id,E.name as user_login_name, B.user_name,D.supplier_id,F.name as supplier_login_name,
//                             D.supplier_name,D.transfer_account,
//                             D.transfer_name,D.transfer_area,D.transfer_bank_n,
//                             D.transfer_bank_a,D.bank_code
//                             from b2b_credit_tally_order_pay as A
//                             left join b2b_credit_tally_order as H ON H.order_sn=A.tally_order_sn
//                             left join b2b_user_info as B on B.user_id=H.user_id
//                             left join b2b_user as E on E.id = B.user_id
//                             left join b2b_supplier_info as D on D.supplier_id = H.supplier_id
//                             left join b2b_supplier as F ON F.id=D.supplier_id
//                             where A.status=2 and A.end_time<'{$start}' group by A.tally_order_sn";
//          $this->addRemittanceListBySql($hk_sql, 1);
        
//         //保证金
//         $bz_sql = "select A.apply_sn as order_sn,A.pay_amount as pay_price,4 as order_type, A.pay_method-1 as pay_method,A.end_time as pay_time,G.apply_times as create_order_time,
//                             B.user_id,E.name as user_login_name, B.user_name,A.supplier_id,F.name as supplier_login_name,
//                             D.supplier_name,D.transfer_account,
//                             D.transfer_name,D.transfer_area,D.transfer_bank_n,
//                             D.transfer_bank_a,D.bank_code
//                             from b2b_credit_apply_pay_log as A
//                             left join b2b_credit_apply_record as G ON G.apply_sn=A.apply_sn
//                             left join b2b_user_info as B on B.user_id=A.payment_user_id
//                             left join b2b_user as E on E.id = A.payment_user_id
//                             left join b2b_supplier_info as D on D.supplier_id = A.supplier_id
//                             left join b2b_supplier as F ON F.id=A.supplier_id
//                             where A.pay_status=2 and A.end_time<'{$start}' group by A.apply_sn";
//         $this->addRemittanceListBySql($bz_sql, 1);
        
//         /******经销商代付汇总截止昨天的*******/
//         $sql = "select supplier_login_name,supplier_name,bank_code,transfer_account,transfer_name,province,city,sum(pay_price) as amount,supplier_id,DATE_FORMAT(pay_time,'%Y-%m-%d') as pay_date
//                         from b2b_supplier_order_pay_remittance_detail
//                         where pay_time<'{$start}' group by supplier_id,pay_date";
//         //汇总信息
//         $remittance_summary_model = M('supplier_pay_remittance_summary');
//         $remittance_summary_arr = $m->query($sql);
        
//         if($remittance_summary_arr){
//             $where = array();
//             $current_info = array();
//             $current_amount = 0.00;
//             $new_amount = 0.00;
//             $update_data = array();
        
//             foreach($remittance_summary_arr as $mpaykey=>$cData){
//                 if($cData['supplier_id']){
//                     $where = array(
//                         'supplier_id'=>$cData['supplier_id'],
//                         'pay_date'=>$cData['pay_date']
//                     );
//                     $current_info = $remittance_summary_model->where($where)->find();
//                     if($current_info){
//                         $new_amount = $cData['amount'];
//                         $update_data = array(
//                             'amount'=>$new_amount,
//                             'updated'=>date('Y-m-d H:i:s', time())
//                         );
//                         $update_res = $remittance_summary_model->where($where)->save($update_data);
//                         if($update_res===false){
//                             $data = array(
//                                 'op_sql'=> $remittance_summary_model->_sql(),
//                                 'err_tip'=>$remittance_summary_model->getDbError(),
//                                 'err_order_sn'=>'空',
//                                 'err_msg'=>'修改经销商代付汇总的汇总金额时失败',
//                                 'add_time'=>date('Y-m-d H:i:s', time())
//                             );
//                             $this->addTabLog($data);
//                         }
//                     }else{
//                         if(empty($current_info) && $current_info!==false){
//                             $insert_res = $remittance_summary_model->data($cData)->add();
//                             if($insert_res===false){
//                                 $data = array(
//                                     'op_sql'=> $remittance_summary_model->_sql(),
//                                     'err_tip'=>$remittance_summary_model->getDbError(),
//                                     'err_order_sn'=>'空',
//                                     'err_msg'=>'新增经销商代付汇总时失败',
//                                     'add_time'=>date('Y-m-d H:i:s', time())
//                                 );
//                                 $this->addTabLog($data);
//                             }
//                         }
//                         if($current_info === false){
//                             $data = array(
//                                 'op_sql'=> $remittance_summary_model->_sql(),
//                                 'err_tip'=>$remittance_summary_model->getDbError(),
//                                 'err_order_sn'=>'空',
//                                 'err_msg'=>'查询是否存在经销商代付汇总时失败',
//                                 'add_time'=>date('Y-m-d H:i:s', time())
//                             );
//                             $this->addTabLog($data);
//                         }
//                     }
//                 }
//             }
//         }else{
//             if($remittance_summary_arr === false){
//                 $data = array(
//                     'op_sql'=>$sql,
//                     'err_tip'=>$m->getDbError(),
//                     'err_order_sn'=>'空',
//                     'err_msg'=>'查询并统计:经销商代付明细的汇总时失败',
//                     'add_time'=>date('Y-m-d H:i:s', time())
//                 );
//                 $this->addTabLog($data);
//             }
//         }
    }
    //厂商截止昨天的
    public function yestodayManufacturer8118(){
//          //exit;
//         //设置php的内存不限制
//         ini_set('memory_limit',-1);
//         //设置php运行时间不限制
//         ini_set("max_execution_time", 0);
        
//         $start = date('Y-m-d 00:00:00', time());
        
//         $m = M();
        
//         //厂商订单
//         $supplier_order_sql = "select C.m_id as manufacturer_id,C.supplier_id,F.user_name as manufacturer_login_name,D.manufacturer_name,D.bank_code,D.collection_acount_branch,D.collection_bank_account,
//                                         D.collection_unit_name,D.open_bank_area,E.supplier_name,G.name as supplier_login_name,
//                                         A.order_sn,C.settlement_price as pay_price,6 as order_type, A.pay as pay_method,A.end_time as pay_time,C.create_time as create_order_time
//                                         from b2b_supplier_order_pay as A
//                                         left join b2b_supplier_order as C on C.order_sn = A.order_sn
//                                         left join b2b_manufacturer_info as D on D.manufacturer_id = C.m_id
//                                         left join b2b_manufacturer as F on F.id = D.manufacturer_id
//                                         left join b2b_supplier_info as E on E.supplier_id = C.supplier_id
//                                         left join b2b_supplier as G on G.id = E.supplier_id
//                                         where A.status='2' and A.end_time<'{$start}' group by A.order_sn";
//         $this->addRemittanceListBySql($supplier_order_sql, 2);

//         /**********厂商代付汇总 截止昨天的**************/
//         $sel_feild = "manufacturer_login_name,manufacturer_name,bank_code,collection_acount_branch,collection_bank_account,
//                       collection_unit_name,province,city,sum(pay_price) as amount,manufacturer_id,DATE_FORMAT(pay_time,'%Y-%m-%d') as pay_date ";
//         $ins_feild = "manufacturer_login_name,manufacturer_name,bank_code,collection_acount_branch,collection_bank_account,collection_unit_name,province,city,amount,manufacturer_id,pay_date";
//         $sql = "select ".$sel_feild."from b2b_manufacturer_order_pay_remittance_detail where pay_time<'{$start}' group by manufacturer_id,pay_date";

//         //汇总信息
//         $remittance_summary_model = M('manufacturer_pay_remittance_summary');
//         $remittance_summary_arr = $m->query($sql);
        
//         if($remittance_summary_arr){
//             $where = array();
//             $current_info = array();
//             $current_amount = 0.00;
//             $new_amount = 0.00;
//             $update_data = array();
        
//             foreach($remittance_summary_arr as $mpaykey=>$cData){
//                 if($cData['manufacturer_id']){
//                     $where = array(
//                         'manufacturer_id'=>$cData['manufacturer_id'],
//                         'pay_date'=>$cData['pay_date']
//                     );
//                     $current_info = $remittance_summary_model->where($where)->find();
//                     if($current_info){
//                         $new_amount = $cData['amount'];
//                         $update_data = array(
//                             'amount'=>$new_amount,
//                             'updated'=>date('Y-m-d H:i:s', time())
//                         );
//                         $update_res = $remittance_summary_model->where($where)->save($update_data);
//                         if($update_res===false){
//                             $data = array(
//                                 'op_sql'=> $remittance_summary_model->_sql(),
//                                 'err_tip'=>$remittance_summary_model->getDbError(),
//                                 'err_order_sn'=>'空',
//                                 'err_msg'=>'修改厂商代付汇总的汇总金额时失败',
//                                 'add_time'=>date('Y-m-d H:i:s', time())
//                             );
//                             $this->addTabLog($data);
//                         }
//                     }else{
//                         if(empty($current_info) && $current_info!==false){
//                             $insert_res = $remittance_summary_model->data($cData)->add();
//                             if($insert_res===false){
//                                 $data = array(
//                                     'op_sql'=> $remittance_summary_model->_sql(),
//                                     'err_tip'=>$remittance_summary_model->getDbError(),
//                                     'err_order_sn'=>'空',
//                                     'err_msg'=>'新增厂商代付汇总时失败',
//                                     'add_time'=>date('Y-m-d H:i:s', time())
//                                 );
//                                 $this->addTabLog($data);
//                             }
//                         }
//                         if($current_info === false){
//                             $data = array(
//                                 'op_sql'=> $remittance_summary_model->_sql(),
//                                 'err_tip'=>$remittance_summary_model->getDbError(),
//                                 'err_order_sn'=>'空',
//                                 'err_msg'=>'查询是否存在厂商代付汇总时失败',
//                                 'add_time'=>date('Y-m-d H:i:s', time())
//                             );
//                             $this->addTabLog($data);
//                         }
//                     }
//                 }
//             }
//         }else{
//             if($remittance_summary_arr === false){
//                 $data = array(
//                     'op_sql'=>$sql,
//                     'err_tip'=>$m->getDbError(),
//                     'err_order_sn'=>'空',
//                     'err_msg'=>'查询并统计:厂商代付明细时失败',
//                     'add_time'=>date('Y-m-d H:i:s', time())
//                 );
//                 $this->addTabLog($data);
//             }
//         }
    }
    
    //截止昨天的    定时任务跑总后台的销售汇总、预付款汇总
    public function yestodayAdminSupplierSaleSummary818(){
//         //exit;
//         //设置php的内存不限制
//         ini_set('memory_limit',-1);
//         //设置php运行时间不限制
//         ini_set("max_execution_time", 0);
//         $start = date('Y-m-d 00:00:00', time());
        
//         $m = M();
        
//         $sql = "select supplier_login_name,supplier_name,sum(pay_price) as amount,supplier_id,DATE_FORMAT(pay_time,'%Y-%m-%d') as pay_date,transfer_account,transfer_name,transfer_bank_n,transfer_bank_a
//                        from b2b_supplier_order_pay_remittance_detail 
//                        where pay_time<'{$start}' and order_type in (0,3) 
//                        group by supplier_id,DATE_FORMAT(pay_time,'%Y-%m-%d')";
//         $supplier_sale_summary_arr = $m->query($sql);
        
//         if($supplier_sale_summary_arr){
//             $supplier_sale_summary_model = M('admin_supplier_sale_summary');
//             $admin_supplier_where = array();
//             $current_admin_supplier_info = array();
//             $current_amount = 0.00;
//             foreach($supplier_sale_summary_arr as $key=>$currentData){
//                 if($currentData['supplier_id']){
//                     $admin_supplier_where = array(
//                         'supplier_id'=>$currentData['supplier_id'],
//                         'pay_date'=>$currentData['pay_date']
//                     );
//                     $current_admin_supplier_info = $supplier_sale_summary_model->where($admin_supplier_where)->find();
//                     if($current_admin_supplier_info){
//                         $current_amount = $currentData['amount'];
//                         $supplier_update_data = array(
//                             'amount'=>$current_amount,
//                             'updated'=>date('Y-m-d H:i:s', time())
//                         );
//                         $supplier_summary_update_res = $supplier_sale_summary_model->where($admin_supplier_where)->save($supplier_update_data);
//                         if($supplier_summary_update_res === false){
//                             $data = array(
//                                 'op_sql'=> $supplier_sale_summary_model->_sql(),
//                                 'err_tip'=>$supplier_sale_summary_model->getDbError(),
//                                 'err_order_sn'=>'空',
//                                 'err_msg'=>'修改销售汇总的金额时失败',
//                                 'add_time'=>date('Y-m-d H:i:s', time())
//                             );
//                             $this->addTabLog($data);
//                         }
//                     }else{
//                         if(empty($current_admin_supplier_info) && $current_admin_supplier_info !== false){
//                             $supplier_summary_insert_res = $supplier_sale_summary_model->data($currentData)->add();
//                             if($supplier_summary_insert_res===false){
//                                 $data = array(
//                                     'op_sql'=> $supplier_sale_summary_model->_sql(),
//                                     'err_tip'=>$supplier_sale_summary_model->getDbError(),
//                                     'err_order_sn'=>'空',
//                                     'err_msg'=>'新增销售汇总时失败',
//                                     'add_time'=>date('Y-m-d H:i:s', time())
//                                 );
//                                 $this->addTabLog($data);
//                             }
//                         }
//                         if($current_admin_supplier_info === false){
//                             $data = array(
//                                 'op_sql'=> $supplier_sale_summary_model->_sql(),
//                                 'err_tip'=>$supplier_sale_summary_model->getDbError(),
//                                 'err_order_sn'=>'空',
//                                 'err_msg'=>'查询是否存在销售汇总时失败',
//                                 'add_time'=>date('Y-m-d H:i:s', time())
//                             );
//                             $this->addTabLog($data);
//                         }
//                     }
//                 }
//             }
        
//         }else{
//             if($supplier_sale_summary_arr === false){
//                 $data = array(
//                     'op_sql'=>$sql,
//                     'err_tip'=>$m->getDbError(),
//                     'err_order_sn'=>'空',
//                     'err_msg'=>'从代付明细查询并统计:销售汇总时失败',
//                     'add_time'=>date('Y-m-d H:i:s', time())
//                 );
//                 $this->addTabLog($data);
//             }
//         }
        
//         //预付款汇总
//         $yf_sql = "select supplier_login_name,supplier_name,sum(pay_price) as amount,supplier_id,user_id,user_name,DATE_FORMAT(pay_time,'%Y-%m-%d') as pay_date,transfer_account,transfer_name,transfer_bank_n,transfer_bank_a 
//                         from b2b_supplier_order_pay_remittance_detail 
//                         where pay_time<'{$start}' and order_type =3 
//                         group by supplier_id,DATE_FORMAT(pay_time,'%Y-%m-%d')"; 
        
//         $gold_sale_summary_arr = $m->query($yf_sql);
        
//         if($gold_sale_summary_arr){
//             $gold_sale_summary_model = M('admin_gold_orde_sale_summary');
        
//             $gold_where = array();
//             $current_gold_info = array();
//             $current_amount = 0.00;
        
//             foreach($gold_sale_summary_arr as $goldKey=>$goldData){
//                 if($currentData['supplier_id']){
//                     $gold_where = array(
//                         'supplier_id'=>$goldData['supplier_id'],
//                         'pay_date'=>$goldData['pay_date']
//                     );
//                     $current_gold_info = $gold_sale_summary_model->where($gold_where)->find();
//                     if($current_gold_info){
//                         $current_amount = $goldData['amount'];
//                         $gold_update_data = array(
//                             'amount'=>$current_amount,
//                             'updated'=>date('Y-m-d H:i:s', time())
//                         );
//                         $gold_update_res = $gold_sale_summary_model->where($gold_where)->save($gold_update_data);
//                         if($gold_update_res === false){
//                             $data = array(
//                                 'op_sql'=> $gold_sale_summary_model->_sql(),
//                                 'err_tip'=>$gold_sale_summary_model->getDbError(),
//                                 'err_order_sn'=>'空',
//                                 'err_msg'=>'修改销售汇总的金额时失败',
//                                 'add_time'=>date('Y-m-d H:i:s', time())
//                             );
//                             $this->addTabLog($data);
//                         }
//                     }else{
//                         if(empty($current_gold_info) && $current_gold_info !== false){
//                             $gold_insert_res = $gold_sale_summary_model->data($goldData)->add();
//                             if($gold_insert_res===false){
//                                 $data = array(
//                                     'op_sql'=> $gold_sale_summary_model->_sql(),
//                                     'err_tip'=>$gold_sale_summary_model->getDbError(),
//                                     'err_order_sn'=>'空',
//                                     'err_msg'=>'新增销售汇总时失败',
//                                     'add_time'=>date('Y-m-d H:i:s', time())
//                                 );
//                                 $this->addTabLog($data);
//                             }
//                         }
//                         if($current_gold_info === false){
//                             $data = array(
//                                 'op_sql'=> $gold_sale_summary_model->_sql(),
//                                 'err_tip'=>$gold_sale_summary_model->getDbError(),
//                                 'err_order_sn'=>'空',
//                                 'err_msg'=>'查询是否存在销售汇总时失败',
//                                 'add_time'=>date('Y-m-d H:i:s', time())
//                             );
//                             $this->addTabLog($data);
//                         }
//                     }
//                 }
//             }
        
//         }else{
//             if($gold_sale_summary_arr === false){
//                 $data = array(
//                     'op_sql'=>$yf_sql,
//                     'err_tip'=>$m->getDbError(),
//                     'err_order_sn'=>'空',
//                     'err_msg'=>'从代付明细查询并统计:销售汇总时失败',
//                     'add_time'=>date('Y-m-d H:i:s', time())
//                 );
//                 $this->addTabLog($data);
//             }
//         }
    }
    
    //每天的定时任务---->总后台的销售汇总、预付款汇总
    public function adminSupplierSaleDetail(){
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);
        
        $start = date('Y-m-d 00:00:00', strtotime('-1 day'));
        $end = date('Y-m-d 23:59:59', strtotime('-1 day'));                
        //检查是否已经执行过
        $this->isOperted(4);
        
        $m = M();
        
        //销售汇总
        $sql = "select supplier_login_name,supplier_name,sum(pay_price) as amount,sum(factorage) factorage,supplier_id,DATE_FORMAT(pay_time,'%Y-%m-%d') as pay_date,transfer_account,transfer_name,transfer_bank_n,transfer_bank_a
                        from b2b_supplier_order_pay_remittance_detail
                        where pay_time>='{$start}' and pay_time<='{$end}' and order_type in (0,3) 
                        group by supplier_id,DATE_FORMAT(pay_time,'%Y-%m-%d')";
        $supplier_sale_summary_arr = $m->query($sql);
        
        if($supplier_sale_summary_arr){
               $supplier_sale_summary_model = M('admin_supplier_sale_summary');
               $admin_supplier_where = array();
               $current_admin_supplier_info = array();
               $current_amount = 0.00;
               foreach($supplier_sale_summary_arr as $key=>$currentData){
                   if($currentData['supplier_id']){
                       $admin_supplier_where = array(
                           'supplier_id'=>$currentData['supplier_id'],
                           'pay_date'=>$currentData['pay_date']
                       );
                       $current_admin_supplier_info = $supplier_sale_summary_model->where($admin_supplier_where)->find();
                       if($current_admin_supplier_info){
                           $current_amount = $currentData['amount'];
                           $supplier_update_data = array(
                               'amount'=>$current_amount,
                           	   'factorage'=>$currentData['factorage'],
                               'updated'=>date('Y-m-d H:i:s', time())
                           );
                           $supplier_summary_update_res = $supplier_sale_summary_model->where($admin_supplier_where)->save($supplier_update_data);
                           if($supplier_summary_update_res === false){
                               $data = array(
                                   'op_sql'=> $supplier_sale_summary_model->_sql(),
                                   'err_tip'=>$supplier_sale_summary_model->getDbError(),
                                   'err_order_sn'=>'空',
                                   'err_msg'=>'修改销售汇总的金额时失败',
                                   'add_time'=>date('Y-m-d H:i:s', time())
                               );
                               $this->addTabLog($data);
                           }
                       }else{
                           if(empty($current_admin_supplier_info) && $current_admin_supplier_info !== false){
                               $supplier_summary_insert_res = $supplier_sale_summary_model->data($currentData)->add();
                               if($supplier_summary_insert_res===false){
                                   $data = array(
                                       'op_sql'=> $supplier_sale_summary_model->_sql(),
                                       'err_tip'=>$supplier_sale_summary_model->getDbError(),
                                       'err_order_sn'=>'空',
                                       'err_msg'=>'新增销售汇总时失败',
                                       'add_time'=>date('Y-m-d H:i:s', time())
                                   );
                                   $this->addTabLog($data);
                               }
                           }
                           if($current_admin_supplier_info === false){
                               $data = array(
                                   'op_sql'=> $supplier_sale_summary_model->_sql(),
                                   'err_tip'=>$supplier_sale_summary_model->getDbError(),
                                   'err_order_sn'=>'空',
                                   'err_msg'=>'查询是否存在销售汇总时失败',
                                   'add_time'=>date('Y-m-d H:i:s', time())
                               );
                               $this->addTabLog($data);
                           }
                       }
                   }
               }
            
        }else{
            if($supplier_sale_summary_arr === false){
                $data = array(
                   'op_sql'=>$sql,
                   'err_tip'=>$m->getDbError(),
                   'err_order_sn'=>'空',
                   'err_msg'=>'从代付明细查询并统计:销售汇总时失败',
                   'add_time'=>date('Y-m-d H:i:s', time())
               );
               $this->addTabLog($data);
            }
        }
    
        //预付款汇总
        $yf_sql = "select supplier_login_name,supplier_name,sum(pay_price) as amount,sum(factorage) factorage,supplier_id,user_id,user_name,DATE_FORMAT(pay_time,'%Y-%m-%d') as pay_date,transfer_account,transfer_name,transfer_bank_n,transfer_bank_a
                    from b2b_supplier_order_pay_remittance_detail
                    where pay_time>='{$start}' and pay_time<='{$end}' and order_type =3 
                    group by supplier_id,DATE_FORMAT(pay_time,'%Y-%m-%d')";
    
        $gold_sale_summary_arr = $m->query($yf_sql);
        
        if($gold_sale_summary_arr){
            $gold_sale_summary_model = M('admin_gold_orde_sale_summary');
            
            $gold_where = array();
            $current_gold_info = array();
            $current_amount = 0.00;
            
            foreach($gold_sale_summary_arr as $goldKey=>$goldData){
                if($currentData['supplier_id']){
                    $gold_where = array(
                        'supplier_id'=>$goldData['supplier_id'],
                        'pay_date'=>$goldData['pay_date']
                    );
                    $current_gold_info = $gold_sale_summary_model->where($gold_where)->find();
                    if($current_gold_info){
                        $current_amount = $goldData['amount'];
                        $gold_update_data = array(
                            'amount'=>$current_amount,
                        	'factorage'=>$goldData['factorage'],
                            'updated'=>date('Y-m-d H:i:s', time())
                        );
                        $gold_update_res = $gold_sale_summary_model->where($gold_where)->save($gold_update_data);
                        if($gold_update_res === false){
                            $data = array(
                                'op_sql'=> $gold_sale_summary_model->_sql(),
                                'err_tip'=>$gold_sale_summary_model->getDbError(),
                                'err_order_sn'=>'空',
                                'err_msg'=>'修改销售汇总的金额时失败',
                                'add_time'=>date('Y-m-d H:i:s', time())
                            );
                            $this->addTabLog($data);
                        }
                    }else{
                        if(empty($current_gold_info) && $current_gold_info !== false){
                            $gold_insert_res = $gold_sale_summary_model->data($goldData)->add();
                            if($gold_insert_res===false){
                                $data = array(
                                    'op_sql'=> $gold_sale_summary_model->_sql(),
                                    'err_tip'=>$gold_sale_summary_model->getDbError(),
                                    'err_order_sn'=>'空',
                                    'err_msg'=>'新增销售汇总时失败',
                                    'add_time'=>date('Y-m-d H:i:s', time())
                                );
                                $this->addTabLog($data);
                            }
                        }
                        if($current_gold_info === false){
                            $data = array(
                                'op_sql'=> $gold_sale_summary_model->_sql(),
                                'err_tip'=>$gold_sale_summary_model->getDbError(),
                                'err_order_sn'=>'空',
                                'err_msg'=>'查询是否存在销售汇总时失败',
                                'add_time'=>date('Y-m-d H:i:s', time())
                            );
                            $this->addTabLog($data);
                        }
                    }
                }
            }
        
        }else{
            if($gold_sale_summary_arr === false){
                $data = array(
                    'op_sql'=>$yf_sql,
                    'err_tip'=>$m->getDbError(),
                    'err_order_sn'=>'空',
                    'err_msg'=>'从代付明细查询并统计:销售汇总时失败',
                    'add_time'=>date('Y-m-d H:i:s', time())
                );
                $this->addTabLog($data);
            }
        }
    }
    
    //截止昨天的定时任务----->跑截止昨天的订单交易统计
    public function yestodayOrdertradelist818(){
//         //exit;
//         //设置php的内存不限制
//         ini_set('memory_limit',-1);
//         //设置php运行时间不限制
//         ini_set("max_execution_time", 0);
//         $start = date('Y-m-d 00:00:00', time());
        
//         //$m = M();
        
//         //零售店普通订单
//         $pt_sql = "select A.order_sn,A.pay_sn,A.pay_price, 1 as user_type, 0 as order_type, A.pay as pay_method,D.supplier_name as seller_name, B.user_name as buyer_name,
//                             A.end_time as pay_time
//                             from b2b_order_pay as A
//                             left join b2b_user_info as B on B.user_id=A.user_id
//                             left join b2b_user_salesman_supplier C on C.user_id=B.user_id
//                             left join b2b_supplier_info as D on D.supplier_id = C.supplier_id
//                             where A.status='2' and A.end_time<'{$start}' group by A.order_sn";
//         $this->addPayOrderlistBySql($pt_sql);
        
//         //零售店回款订单
//         $hk_sql = "select A.tally_order_sn as order_sn, A.pay_sn,A.pay_amount as pay_price,1 as user_type, 2 as order_type,A.pay_method-1 as pay_method,
//                             C.supplier_name as seller_name,D.user_name as buyer_name,A.end_time as pay_time
//                             from b2b_credit_tally_order_pay as A
//                             left join b2b_supplier_info as C on C.supplier_id = A.supplier_id
//                             left join b2b_user_info as D on D.user_id  = A.payment_user_id
//                             where A.status=2 and A.end_time<'{$start}' group by A.tally_order_sn";
//         $this->addPayOrderlistBySql($hk_sql);
        
//         //零售店加盟费
//         $jm_sql = "select A.order_sn,A.pay_sn,A.pay_amount as pay_price, 1 as user_type, 5 as order_type, A.pay_method-1 as pay_method, '农集网' AS seller_name,B.user_name AS buyer_name,
//                             A.payment_time as pay_time from b2b_njw_join_order_pay as A
//                             left join b2b_user_info as B on B.user_id = A.user_id
//                             left join b2b_njw_join_order as E ON E.order_sn=A.order_sn
//                             where A.payment_status=1 and E.type=0 and A.payment_time<'{$start}' group by A.order_sn";
//         $this->addPayOrderlistBySql($jm_sql);
        
//         //零售店预付款
//         $yf_sql = "select A.order_sn, A.pay_sn,A.pay_amount as pay_price,1 as user_type, 3 as order_type,A.pay_method-1 as pay_method,
//                             C.supplier_name as seller_name,D.user_name as buyer_name,A.payment_time as pay_time
//                             from b2b_njw_gold_order_pay as A
//                             left join b2b_user_salesman_supplier as B on B.user_id=A.user_id
//                             left join b2b_supplier_info as C on C.supplier_id=B.supplier_id
//                             left join b2b_user_info as D on D.user_id = A.user_id
//                             where A.payment_status=2 and A.payment_time<'{$start}' group by A.order_sn";
//         $this->addPayOrderlistBySql($yf_sql);

//         //零售店保证金
//         $bz_sql = "select A.apply_sn as order_sn,A.pay_sn,A.pay_amount as pay_price, 1 as user_type, 4 as order_type,A.pay_method-1 as pay_method,
//                             B.supplier_name as seller_name,C.user_name as buyer_name,A.end_time as pay_time
//                             from b2b_credit_apply_pay_log as A
//                             left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//                             left join b2b_user_info as C on C.user_id= A.payment_user_id
//                             where A.pay_status=2 and A.end_time<'{$start}' group by A.apply_sn";
//         $this->addPayOrderlistBySql($bz_sql);
        
//         //厂商订单
//         $supplier_order_sql = "select A.order_sn,A.pay_sn,A.pay_price, 2 as user_type,6 as order_type, A.pay as pay_method,D.manufacturer_name AS seller_name,B.supplier_name AS buyer_name,A.end_time as pay_time
//                                         from b2b_supplier_order_pay as A
//                                         left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//                                         left join b2b_supplier_order as C on C.order_sn = A.order_sn
//                                         left join b2b_manufacturer_info as D on D.manufacturer_id = C.m_id
//                                         where A.status='2' and A.pay<2 and A.end_time<'{$start}' group by A.order_sn";
//         $this->addPayOrderlistBySql($supplier_order_sql);

//         //厂商账户余额订单
//         $supplier_order_yuer_sql = "select A.order_sn,A.pay_sn,A.pay_price, 2 as user_type,9 as order_type, A.pay as pay_method,D.manufacturer_name AS seller_name,B.supplier_name AS buyer_name,A.end_time as pay_time
//                                             from b2b_supplier_order_pay as A
//                                             left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//                                             left join b2b_supplier_order as C on C.order_sn = A.order_sn
//                                             left join b2b_manufacturer_info as D on D.manufacturer_id = C.m_id
//                                             where A.status='2' and A.pay=2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.order_sn";
//         $this->addPayOrderlistBySql($supplier_order_yuer_sql);
        
//         //厂商回款订单
//         $supplier_sh_sql = "select A.tally_order_sn as order_sn,A.pay_sn,A.pay_amount as pay_price, 2 as user_type,7 as order_type, A.pay_method-1 as pay_method,D.manufacturer_name AS seller_name,B.supplier_name AS buyer_name,
//                                     A.end_time as pay_time from b2b_supplier_credit_order_pay as A
//                                     left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//                                     left join b2b_manufacturer_supplier as C on C.supplier_id=B.supplier_id
//                                     left join b2b_manufacturer_info as D on D.manufacturer_id = C.manufacturer_id
//                                     where A.status=2 and A.end_time<'{$start}' group by A.tally_order_sn";
//         $this->addPayOrderlistBySql($supplier_sh_sql);
        
//         //厂商加盟费
//         $supplier_jm_sql = "select A.order_sn,A.pay_sn,A.pay_amount as pay_price, 2 as user_type, 5 as order_type, A.pay_method-1 as pay_method, '农集网' AS seller_name,B.supplier_name AS buyer_name,
//                                     A.payment_time as pay_time from b2b_njw_join_order_pay as A
//                                     left join b2b_supplier_info as B on B.supplier_id = A.user_id
//                                     left join b2b_njw_join_order as E ON E.order_sn=A.order_sn
//                                     where A.payment_status=1 and E.type=1 and A.payment_time<'{$start}' group by A.order_sn";
//         $this->addPayOrderlistBySql($supplier_jm_sql);
        
//         //预售活动的保证金
//         $yushou_sql = "select F.order_sn,A.payment_sn as pay_sn,A.payment_amount as pay_price, 2 as user_type, 8 as order_type, A.payment_method as pay_method, '农集网' AS seller_name, B.supplier_name AS buyer_name,
//                                     A.complete_date as pay_time
//                                     from b2b_supplier_actreserve_order_pay as A
//                                     left join b2b_supplier_actreserve_order as F ON F.id=A.act_order_id
//                                     left join b2b_supplier_info as B on B.supplier_id = F.supplier_id 
//                                     where A.payment_status=2 and A.complete_date<'{$start}' group by F.order_sn";
//         $this->addPayOrderlistBySql($yushou_sql);
    }
    
    //测试专用的----截止昨天的定时任务----->跑截止昨天的订单交易统计
    public function newyestodayOrdertradelist(){
//         //exit;
//         //设置php的内存不限制
//         ini_set('memory_limit',-1);
//         //设置php运行时间不限制
//         ini_set("max_execution_time", 0);
//         //$start = date('Y-m-d 00:00:00', time());
//         $start = '2015-12-13 00:00:00';
//         $end = '2016-01-13 23:59:59';
    
//         //$m = M();
    
//         //零售店普通订单
//         $pt_sql = "select A.order_sn,A.pay_sn,A.pay_price, 1 as user_type, 0 as order_type, A.pay as pay_method,D.supplier_name as seller_name, B.user_name as buyer_name,
//         A.end_time as pay_time
//         from b2b_order_pay as A
//         left join b2b_user_info as B on B.user_id=A.user_id
//         left join b2b_user_salesman_supplier C on C.user_id=B.user_id
//         left join b2b_supplier_info as D on D.supplier_id = C.supplier_id
//         where A.status='2' and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.order_sn";
//         $this->addPayOrderlistBySql($pt_sql);
    
//         //零售店回款订单
//         $hk_sql = "select A.tally_order_sn as order_sn, A.pay_sn,A.pay_amount as pay_price,1 as user_type, 2 as order_type,A.pay_method-1 as pay_method,
//         C.supplier_name as seller_name,D.user_name as buyer_name,A.end_time as pay_time
//         from b2b_credit_tally_order_pay as A
//         left join b2b_supplier_info as C on C.supplier_id = A.supplier_id
//         left join b2b_user_info as D on D.user_id  = A.payment_user_id
//         where A.status=2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.tally_order_sn";
//         $this->addPayOrderlistBySql($hk_sql);
    
//         //零售店加盟费
//         $jm_sql = "select A.order_sn,A.pay_sn,A.pay_amount as pay_price, 1 as user_type, 5 as order_type, A.pay_method-1 as pay_method, '农集网' AS seller_name,B.user_name AS buyer_name,
//         A.payment_time as pay_time from b2b_njw_join_order_pay as A
//         left join b2b_user_info as B on B.user_id = A.user_id
//         left join b2b_njw_join_order as E ON E.order_sn=A.order_sn
//         where A.payment_status=1 and E.type=0 and A.payment_time>='{$start}' and A.payment_time<='{$end}' group by A.order_sn";
//         $this->addPayOrderlistBySql($jm_sql);
    
//         //零售店预付款
//         $yf_sql = "select A.order_sn, A.pay_sn,A.pay_amount as pay_price,1 as user_type, 3 as order_type,A.pay_method-1 as pay_method,
//         C.supplier_name as seller_name,D.user_name as buyer_name,A.payment_time as pay_time
//         from b2b_njw_gold_order_pay as A
//         left join b2b_user_salesman_supplier as B on B.user_id=A.user_id
//         left join b2b_supplier_info as C on C.supplier_id=B.supplier_id
//         left join b2b_user_info as D on D.user_id = A.user_id
//         where A.payment_status=2 and A.payment_time>='{$start}' and A.payment_time<='{$end}' group by A.order_sn";
//         $this->addPayOrderlistBySql($yf_sql);
    
//         //零售店保证金
//         $bz_sql = "select A.apply_sn as order_sn,A.pay_sn,A.pay_amount as pay_price, 1 as user_type, 4 as order_type,A.pay_method-1 as pay_method,
//         B.supplier_name as seller_name,C.user_name as buyer_name,A.end_time as pay_time
//         from b2b_credit_apply_pay_log as A
//         left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//         left join b2b_user_info as C on C.user_id= A.payment_user_id
//         where A.pay_status=2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.apply_sn";
//         $this->addPayOrderlistBySql($bz_sql);
    
//         //厂商订单
//         $supplier_order_sql = "select A.order_sn,A.pay_sn,A.pay_price, 2 as user_type,6 as order_type, A.pay as pay_method,D.manufacturer_name AS seller_name,B.supplier_name AS buyer_name,A.end_time as pay_time
//         from b2b_supplier_order_pay as A
//         left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//         left join b2b_supplier_order as C on C.order_sn = A.order_sn
//         left join b2b_manufacturer_info as D on D.manufacturer_id = C.m_id
//         where A.status='2' and A.pay<2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.order_sn";
//         $this->addPayOrderlistBySql($supplier_order_sql);
    
//         //厂商账户余额订单
//         $supplier_order_yuer_sql = "select A.order_sn,A.pay_sn,A.pay_price, 2 as user_type,9 as order_type, A.pay as pay_method,D.manufacturer_name AS seller_name,B.supplier_name AS buyer_name,A.end_time as pay_time
//         from b2b_supplier_order_pay as A
//         left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//         left join b2b_supplier_order as C on C.order_sn = A.order_sn
//         left join b2b_manufacturer_info as D on D.manufacturer_id = C.m_id
//         where A.status='2' and A.pay=2 and A.end_time>='{$start}' and A.end_time<='{$end}' and A.end_time<='{$end}' group by A.order_sn";
//         $this->addPayOrderlistBySql($supplier_order_yuer_sql);
    
//         //厂商回款订单
//         $supplier_sh_sql = "select A.tally_order_sn as order_sn,A.pay_sn,A.pay_amount as pay_price, 2 as user_type,7 as order_type, A.pay_method-1 as pay_method,D.manufacturer_name AS seller_name,B.supplier_name AS buyer_name,
//         A.end_time as pay_time from b2b_supplier_credit_order_pay as A
//         left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//         left join b2b_manufacturer_supplier as C on C.supplier_id=B.supplier_id
//         left join b2b_manufacturer_info as D on D.manufacturer_id = C.manufacturer_id
//         where A.status=2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.tally_order_sn";
//         $this->addPayOrderlistBySql($supplier_sh_sql);
    
//         //厂商加盟费
//         $supplier_jm_sql = "select A.order_sn,A.pay_sn,A.pay_amount as pay_price, 2 as user_type, 5 as order_type, A.pay_method-1 as pay_method, '农集网' AS seller_name,B.supplier_name AS buyer_name,
//         A.payment_time as pay_time from b2b_njw_join_order_pay as A
//         left join b2b_supplier_info as B on B.supplier_id = A.user_id
//         left join b2b_njw_join_order as E ON E.order_sn=A.order_sn
//         where A.payment_status=1 and E.type=1 and A.payment_time>='{$start}' and A.payment_time<='{$end}' group by A.order_sn";
//         $this->addPayOrderlistBySql($supplier_jm_sql);
    
//         //预售活动的保证金
//         $yushou_sql = "select F.order_sn,A.payment_sn as pay_sn,A.payment_amount as pay_price, 2 as user_type, 8 as order_type, A.payment_method as pay_method, '农集网' AS seller_name, B.supplier_name AS buyer_name,
//         A.complete_date as pay_time
//         from b2b_supplier_actreserve_order_pay as A
//         left join b2b_supplier_actreserve_order as F ON F.id=A.act_order_id
//         left join b2b_supplier_info as B on B.supplier_id = F.supplier_id
//         where A.payment_status=2 and A.complete_date>='{$start}' and A.complete_date<='{$end}' group by F.order_sn";
//         $this->addPayOrderlistBySql($yushou_sql);

//         //经销商充值订单
//         $_jxscz_sql = "select A.order_sn,A.pay_sn,A.pay_price, 2 as user_type, 10 as order_type, A.pay as pay_method, '农集网' AS seller_name, B.supplier_name AS buyer_name,A.end_time as pay_time
//         from b2b_supplier_recharge_order_pay as A left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//         where A.status='2' and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.order_sn";
//         $this->addPayOrderlistBySql($_jxscz_sql);
    }
    
    //昨天的订单交易明细订单任务
    public function ordertradepaydetail(){
        //设置php的内存不限制
        ini_set('memory_limit',-1);
        //设置php运行时间不限制
        ini_set("max_execution_time", 0);

       $start = date('Y-m-d 00:00:00', strtotime('-1 day'));
       $end = date('Y-m-d 23:59:59', strtotime('-1 day'));
       
        //检查是否已经执行过
        $this->isOperted(1);
        
        //零售店普通订单
        $pt_sql = "select A.order_sn,A.pay_sn,A.pay_price, 1 as user_type, 0 as order_type, A.pay as pay_method,D.supplier_name as seller_name, B.user_name as buyer_name,
                            A.end_time as pay_time,A.user_id bid,C.supplier_id sid
                            from b2b_order_pay as A
                            left join b2b_user_info as B on B.user_id=A.user_id
                            left join b2b_user_salesman_supplier C on C.user_id=B.user_id
                            left join b2b_supplier_info as D on D.supplier_id = C.supplier_id
                            where A.status='2' and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.order_sn";
        $this->addPayOrderlistBySql($pt_sql);
        
        //零售店回款订单
        $hk_sql = "select A.tally_order_sn as order_sn, A.pay_sn,A.pay_amount as pay_price,1 as user_type, 2 as order_type,A.pay_method-1 as pay_method,
                                C.supplier_name as seller_name,D.user_name as buyer_name,A.end_time as pay_time,D.user_id bid,A.supplier_id sid
                                from b2b_credit_tally_order_pay as A
                                left join b2b_supplier_info as C on C.supplier_id = A.supplier_id
                                left join b2b_user_info as D on D.user_id  = A.payment_user_id
                                where A.status=2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.tally_order_sn";
        $this->addPayOrderlistBySql($hk_sql);
        
        //零售店加盟费
        $jm_sql = "select A.order_sn,A.pay_sn,A.pay_amount as pay_price, 1 as user_type, 5 as order_type, A.pay_method-1 as pay_method, '农集网' AS seller_name,B.user_name AS buyer_name,
                            A.payment_time as pay_time ,A.user_id bid
                            from b2b_njw_join_order_pay as A
                            left join b2b_user_info as B on B.user_id = A.user_id
                            left join b2b_njw_join_order as E ON E.order_sn=A.order_sn
                            where A.payment_status=1 and E.type=0 and A.payment_time>='{$start}' and A.payment_time<='{$end}' group by A.order_sn";
        $this->addPayOrderlistBySql($jm_sql);
        
        //零售店预付款
        $yf_sql = "select A.order_sn, A.pay_sn,A.pay_amount as pay_price,1 as user_type, 3 as order_type,A.pay_method-1 as pay_method,
                            C.supplier_name as seller_name,D.user_name as buyer_name,A.payment_time as pay_time,A.user_id bid,B.supplier_id sid
                            from b2b_njw_gold_order_pay as A
                            left join b2b_user_salesman_supplier as B on B.user_id=A.user_id
                            left join b2b_supplier_info as C on C.supplier_id=B.supplier_id
                            left join b2b_user_info as D on D.user_id = A.user_id
                            where A.payment_status=2 and A.payment_time>='{$start}' and A.payment_time<='{$end}' group by A.order_sn";
        $this->addPayOrderlistBySql($yf_sql);
        
        //零售店保证金
        $bz_sql = "select A.apply_sn as order_sn,A.pay_sn,A.pay_amount as pay_price, 1 as user_type, 4 as order_type,A.pay_method-1 as pay_method,
                            B.supplier_name as seller_name,C.user_name as buyer_name,A.end_time as pay_time,A.supplier_id sid , C.user_id bid
                            from b2b_credit_apply_pay_log as A
                            left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
                            left join b2b_user_info as C on C.user_id= A.payment_user_id
                            where A.pay_status=2 and A.end_time>='{$start}' and  A.end_time<='{$end}' group by A.apply_sn";
        $this->addPayOrderlistBySql($bz_sql);
        
        //厂商订单
        $supplier_order_sql = "select A.order_sn,A.pay_sn,A.pay_price, 2 as user_type,6 as order_type, A.pay as pay_method,D.manufacturer_name AS seller_name,B.supplier_name AS buyer_name,A.end_time as pay_time
                                        ,A.supplier_id bid, C.m_id sid
                                        from b2b_supplier_order_pay as A
                                        left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
                                        left join b2b_supplier_order as C on C.order_sn = A.order_sn
                                        left join b2b_manufacturer_info as D on D.manufacturer_id = C.m_id
                                        where A.status='2' and A.pay<2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.order_sn";
        $this->addPayOrderlistBySql($supplier_order_sql);
        
        //厂商账户余额订单
        $supplier_order_yuer_sql = "select A.order_sn,A.pay_sn,A.pay_price, 2 as user_type,9 as order_type, A.pay as pay_method,D.manufacturer_name AS seller_name,B.supplier_name AS buyer_name,A.end_time as pay_time
                                            ,A.supplier_id bid , C.m_id sid
                                            from b2b_supplier_order_pay as A
                                            left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
                                            left join b2b_supplier_order as C on C.order_sn = A.order_sn
                                            left join b2b_manufacturer_info as D on D.manufacturer_id = C.m_id
                                            where A.status='2' and A.pay=2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.order_sn";
        $this->addPayOrderlistBySql($supplier_order_yuer_sql);
        
        //厂商回款订单
        $supplier_sh_sql = "select A.tally_order_sn as order_sn,A.pay_sn,A.pay_amount as pay_price, 2 as user_type,7 as order_type, A.pay_method-1 as pay_method,D.manufacturer_name AS seller_name,B.supplier_name AS buyer_name,
                                    A.end_time as pay_time ,A.supplier_id bid,C.manufacturer_id sid
                                    from b2b_supplier_credit_order_pay as A
                                    left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
                                    left join b2b_manufacturer_supplier as C on C.supplier_id=B.supplier_id
                                    left join b2b_manufacturer_info as D on D.manufacturer_id = C.manufacturer_id
                                    where A.status=2 and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.tally_order_sn";
        
        $this->addPayOrderlistBySql($supplier_sh_sql);
        
        //厂商加盟费
        $supplier_jm_sql = "select A.order_sn,A.pay_sn,A.pay_amount as pay_price, 2 as user_type, 5 as order_type, A.pay_method-1 as pay_method, '农集网' AS seller_name,B.supplier_name AS buyer_name,
                                    A.payment_time as pay_time , A.user_id bid 
                                    from b2b_njw_join_order_pay as A
                                    left join b2b_supplier_info as B on B.supplier_id = A.user_id
                                    left join b2b_njw_join_order as E ON E.order_sn=A.order_sn
                                    where A.payment_status=1 and E.type=1 and A.payment_time>='{$start}' and A.payment_time<='{$end}' group by A.order_sn";
        $this->addPayOrderlistBySql($supplier_jm_sql);
        
        //预售活动的保证金
        $yushou_sql = "select F.order_sn,A.payment_sn as pay_sn,A.payment_amount as pay_price, 2 as user_type, 8 as order_type, A.payment_method as pay_method, '农集网' AS seller_name, B.supplier_name AS buyer_name,
                                A.complete_date as pay_time,B.supplier_id bid
                                from b2b_supplier_actreserve_order_pay as A
                                left join b2b_supplier_actreserve_order as F ON F.id=A.act_order_id
                                left join b2b_supplier_info as B on B.supplier_id = F.supplier_id 
                                where A.payment_status=2 and A.complete_date>='{$start}' and A.complete_date<='{$end}' group by F.order_sn";
        
        $this->addPayOrderlistBySql($yushou_sql);
        
        //经销商充值订单
        $jxscz_sql = "select A.order_sn,A.pay_sn,A.pay_price, 2 as user_type, 10 as order_type, A.pay as pay_method, '深圳田田圈农业服务有限公司' AS seller_name, B.supplier_name AS buyer_name,A.end_time as pay_time
                       ,A.supplier_id bid
                       from b2b_supplier_recharge_order_pay as A left join b2b_supplier_info as B on B.supplier_id = A.supplier_id 
                       where A.status='2' and A.end_time>='{$start}' and A.end_time<='{$end}' group by A.order_sn";
        $this->addPayOrderlistBySql($jxscz_sql);
    }
    
    //测试方法
    public function test(){
//         //经销商充值订单
//         $end = '2016-01-14 23:59:59';
//         $stat = '2015-06-01 00:00:00';
        
//         $jxscz_sql = "select A.order_sn,A.pay_sn,A.pay_price, 2 as user_type, 10 as order_type, A.pay as pay_method, '深圳田田圈农业服务有限公司' AS seller_name, B.supplier_name AS buyer_name,A.end_time as pay_time
//                         from b2b_supplier_recharge_order_pay as A left join b2b_supplier_info as B on B.supplier_id = A.supplier_id
//                         where A.status='2' and A.end_time>='{$stat}' and A.end_time<='{$end}' group by A.order_sn";
        
//         $this->addPayOrderlistBySql($jxscz_sql);
    }
    
    //根据sql语句 添加代付明细 $user_type = 1 经销商   $user_type = 2 厂商
    public function addRemittanceListBySql($sql,  $user_type=1){
        $m = M();
        $remittance_detail_model = M('supplier_order_pay_remittance_detail');
        if($user_type==1){
            $remittance_detail_model = M('supplier_order_pay_remittance_detail');
        }
        if($user_type==2){
            $remittance_detail_model = M('manufacturer_order_pay_remittance_detail');
        }
        
        $all_order_arr = $m->query($sql);
        
        $where = array();
        $current_info = array();
        $current_res = false;
        $current_area = 0;
        
        if($all_order_arr){
            foreach($all_order_arr as $key=>$current_data){
                $where = array('order_sn'=>$current_data['order_sn']);
                $current_info = $remittance_detail_model->where($where)->find();
                //没有统计过
                if(empty($current_info) && $current_info!==false){
                	$w['order_sn'] = $current_data['order_sn'];
                	$count = M('pos_pay_log')->where($w)->count();
                	$current_data['pay_method'] = $count>=1?1:0;
                	$factorage = $user_type==2?0:$this->getBankServicefee($current_data['pay_price'], $current_data['pay_method']+1);
                	$payfor_amount = round($current_data['pay_price']-$factorage, 2);
                	$current_data['factorage'] = $factorage;
                	$current_data['payfor_amount'] = $payfor_amount;
                    $current_res = $remittance_detail_model->data($current_data)->add();
                    //成功时
                    if($current_res){
                        if($user_type==1){//经销商开户行
                            $current_area = $current_data['transfer_area'];
                        }
                        if($user_type==2){//厂商开户行
                            $current_area = $current_data['open_bank_area'];
                        }
                        $this->setProvicecity($current_data['order_sn'], $current_area, $user_type);
                    }
                    //执行失败时
                    if($current_res === false || empty($current_res)){
                        $data = array(
                            'op_sql'=>$remittance_detail_model->_sql(),
                            'err_tip'=>$remittance_detail_model->getDbError(),
                            'err_order_sn'=>$current_data['order_sn'],
                            'err_msg'=>'根据支付流水表插入代付明细时失败',
                            'add_time'=>date('Y-m-d H:i:s', time())
                        );
                        $this->addTabLog($data);
                    }
                }
                //查询失败时
                if($current_info ===false){
                    $data = array(
                        'op_sql'=>$remittance_detail_model->_sql(),
                        'err_tip'=>$remittance_detail_model->getDbError(),
                        'err_order_sn'=>'空',
                        'err_msg'=>'根据支付流水表查询代付明细是否存在时失败',
                        'add_time'=>date('Y-m-d H:i:s', time())
                    );
                    $this->addTabLog($data);
                }
                 
            }
        }else{
            //查询失败时
            if($all_order_arr === false){
                $data = array(
                    'op_sql'=>$sql,
                    'err_tip'=>$m->getDbError(),
                    'err_order_sn'=>'空',
                    'err_msg'=>'根据支付流水表查询并统计:代付明细时时失败',
                    'add_time'=>date('Y-m-d H:i:s', time())
                );
                $this->addTabLog($data);
            }
        }
    }
    
    //设置代付明细的开户行省市 $type=1 经销商 $type=2 厂商
    public function setProvicecity($order_sn, $area, $type=1){
        $bObj = new \Admin\Model\AreaModel();
         if($order_sn && $area){
             //默认为经销商
             $model = M('supplier_order_pay_remittance_detail');
             if($type==1){//经销商  transfer_area
                 $model = M('supplier_order_pay_remittance_detail');
             }
             if($type==2){//厂商 open_bank_area
                 $model = M('manufacturer_order_pay_remittance_detail');
             }
             //获取省市
             $cachek_wenjinghao_area = 'wenjinghao_transfer_area_2015'.$area;
             if(S($cachek_wenjinghao_area)){
                 $areaInfo = S($cachek_wenjinghao_area);
             }else{
                 $areaInfo = $this->getProvinceAndCityByArea($area, $bObj);
                 S($cachek_wenjinghao_area,$areaInfo, 360000);
             }
             
             $where = array('order_sn'=>$order_sn);
             
             $province = $areaInfo['province'];
             $city = $areaInfo['city'];
             
             $update_data = array(
                 'province'=>$province,
                 'city'=>$city,
                 'updated'=>date('Y-m-d H:i:s', time())
             );
             $cityRes = $model->where($where)->save($update_data);
             if(empty($cityRes)){
                 $data = array(
                     'op_sql'=>$model->_sql(),
                     'err_tip'=>$model->getDbError(),
                     'err_order_sn'=>$order_sn,
                     'err_msg'=>'设置代付明细的省市时失败',
                     'add_time'=>date('Y-m-d H:i:s', time())
                 );
                 $this->addTabLog($data);
             }
         }
    }
    
    //补充遗留的省市
    public function budanProvicecity(){
        $m = M();
        //先补充经销商
        $s_sql = "select order_sn,transfer_area from b2b_supplier_order_pay_remittance_detail where pay_time>='2015-11-11 00:00:00'";
        $all_supplier_detail = $m->query($s_sql);
        
        foreach($all_supplier_detail as $key=>$val){
            if($val['transfer_area']){
                $this->setProvicecity($val['order_sn'], $val['transfer_area'], 1);
            }
        }
        //补充厂商的
        $m_sql = "select order_sn,open_bank_area from b2b_manufacturer_order_pay_remittance_detail where pay_time>='2015-11-11 00:00:00'";
        
        $all_m_detail = $m->query($m_sql);
        
        foreach($all_m_detail as $mkey=>$mval){
            if($mval['open_bank_area']){
                $this->setProvicecity($mval['order_sn'], $mval['open_bank_area'], 2);
            }
        }
        
    }
    
    //补充代付汇总的省市
    public function budanhuizongProvicecity(){
        $bObj = new \Admin\Model\AreaModel();
        $m = M();
        //先补充经销商
        $s_sql = "select A.id,A.supplier_id,B.transfer_area from b2b_supplier_pay_remittance_summary AS A 
                            LEFT JOIN b2b_supplier_info AS B ON B.supplier_id=A.supplier_id
                            where A.pay_date>='2015-11-11'";
        $all_supplier_detail = $m->query($s_sql);
        
        $sum_model = M('supplier_pay_remittance_summary');
        
        foreach($all_supplier_detail as $key=>$val){
            if($val['transfer_area']){
                //获取省市
                $cachek_wenjinghao_area = 'wenjinghao_transfer_area_2015'.$val['transfer_area'];
                if(S($cachek_wenjinghao_area)){
                    $areaInfo = S($cachek_wenjinghao_area);
                }else{
                    $areaInfo = $this->getProvinceAndCityByArea($val['transfer_area'], $bObj);
                    S($cachek_wenjinghao_area,$areaInfo, 360000);
                }
                
                $province = $areaInfo['province'];
                $city = $areaInfo['city'];
                $where = array(
                    'id'=>$val['id']
                );
                $sum_update_data = array(
                    'province'=>$province,
                    'city'=>$city
                );
                $sum_model->where($where)->save($sum_update_data);
            }
        }
        //补充厂商的
        $m_sql = "select A.id,A.manufacturer_id,B.open_bank_area from b2b_manufacturer_pay_remittance_summary AS A left join 
                            b2b_manufacturer_info as B on B.manufacturer_id=A.manufacturer_id
                            where A.pay_date>='2015-11-11'";
    
        $all_m_detail = $m->query($m_sql);
        
        $m_sum_model = M('manufacturer_pay_remittance_summary');
    
        foreach($all_m_detail as $mkey=>$mval){
            if($mval['open_bank_area']){
                 //获取省市
                $cachek_wenjinghao_area = 'wenjinghao_transfer_area_2015'.$mval['open_bank_area'];
                if(S($cachek_wenjinghao_area)){
                    $m_areaInfo = S($cachek_wenjinghao_area);
                }else{
                    $m_areaInfo = $this->getProvinceAndCityByArea($mval['open_bank_area'], $bObj);
                    S($cachek_wenjinghao_area,$m_areaInfo, 360000);
                }
                
                $m_province = $m_areaInfo['province'];
                $m_city = $m_areaInfo['city'];
                $m_where = array(
                    'id'=>$val['id']
                );
                $m_sum_update_data = array(
                    'province'=>$m_province,
                    'city'=>$m_city
                );
                $m_sum_model->where($m_where)->save($m_sum_update_data);
            }
        }
    
    }
    
    //根据sql语句 添加统计交易
    public function addPayOrderlistBySql($sql){
        $m = M();
        $trade_list_model = M('order_pay_trade_list');
        
        $all_order_arr = $m->query($sql);
        
        $where = array();
        $current_info = array();
        $current_res = false;
        
        if($all_order_arr){
             foreach($all_order_arr as $key=>$current_data){
                 $where = array('order_sn'=>$current_data['order_sn']);
                 $current_info = $trade_list_model->where($where)->find();
                 //没有统计过
                 if(empty($current_info) && $current_info!==false){
                     $current_res = $trade_list_model->data($current_data)->add();
                     //执行失败时
                     if($current_res === false || empty($current_res)){
                         $data = array(
                             'op_sql'=>$trade_list_model->_sql(),
                             'err_tip'=>$trade_list_model->getDbError(),
                             'err_order_sn'=>$current_data['order_sn'],
                             'err_msg'=>'根据支付流水表插入交易统计时失败',
                             'add_time'=>date('Y-m-d H:i:s', time())
                         );
                         $this->addTabLog($data);
                     }
                 }
                 //查询失败时
                 if($current_info ===false){
                     $data = array(
                        'op_sql'=>$trade_list_model->_sql(),
                        'err_tip'=>$trade_list_model->getDbError(),
                        'err_order_sn'=>$current_data['order_sn'],
                        'err_msg'=>'根据支付流水表查询交易统计是否存在时失败',
                        'add_time'=>date('Y-m-d H:i:s', time())
                     );
                     $this->addTabLog($data);
                 }
                 
             }
        }else{
            //查询失败时
            if($all_order_arr === false){
                $data = array(
                    'op_sql'=>$sql,
                    'err_tip'=>$m->getDbError(),
                    'err_order_sn'=>'空',
                    'err_msg'=>'根据支付流水表查询订单时失败',
                    'add_time'=>date('Y-m-d H:i:s', time())
                );
                $this->addTabLog($data);
            }
        }
    }
    
    //添加定时任务的的日志
    public function addTabLog($data){
          $daifu_operate_log_model = M('wjh_jiaoyi_daifu_operate_log');
          $daifu_operate_log_model->data($data)->add();
    }
    
    //检查是否已经执行过
    public function isOperted($op_type){
        //检查定时器是否已经执行过
        $operate_log_model = M('jiaoyitongji_contab_log');
        $operate_date = date('Y-m-d', strtotime('-1 day'));
        
        $operate_where = array(
            'operate_date'=>$operate_date,
            'operate_type'=>$op_type
        );
        $operate_info = $operate_log_model->where($operate_where)->find();
        
        //已经执行过 则直接退出
        if($operate_info){
            exit;
        }
        //否则先添加  定时器执行记录
        $operated_data = array(
            'operate_date'=>$operate_date,
            'operate_type'=>$op_type
        );
        $res = $operate_log_model->data($operated_data)->add();
        if(empty($res)){
            exit;
        }
    }
    
    //计算手续费
    public function getBankServicefee($amount=0, $pay_method=1){
        $fee = 0.00;
        //验证金额
        if(!is_numeric($amount) || $amount<=0){
            return $fee;
        }
    
        //验证支付方式
        if(!in_array($pay_method, array(1,2))){
            return $fee;
        }
    
        $pay_method = intval($pay_method);
    
        switch($pay_method) {
            case 1:  //在线支付
                $fee = round($amount*0.007, 2);
                break;
            case 2: //pos支付
                if($amount>=3000){
                    $fee = 26.00;
                }else{
                    $fee = round($amount*0.007, 2);
                }
                break;
        }
        return $fee;
    }
    
    /**
     * 根据地区编码获取地区信息
     * @param int $areaSn
     * @return arr $areaNameArr
     */
    public function getProvinceAndCityByArea($areaSn,$bObj){
        $areaNameArr = array();
        //地区id非法处理
        if(!is_numeric($areaSn)){
            return $areaNameArr;
        }
    
        $key = 'wenjinghhao-sheng-shi-areaName-arr-' . $areaSn;
    
        //是否命中缓存
        if(S($key)){
            $areaNameArr = S($key);
            return $areaNameArr;
        }else{
            $areaNameArr = $bObj->getAreaNameListBySn($areaSn);
            S($key, $areaNameArr);
            return $areaNameArr;
        }
        return $areaNameArr;
    }

}
<?php
namespace Admin\Controller;


use Org\Util\String;
/**
 * 经销商订单汇总模块
 * @author jiangshilin 
 *
 */
 
class SupplierOrderController extends AdminController {

	private $table_prefix;
	public function _initialize()
	{
		parent::_initialize();
		$this->table_prefix = C('DB_PREFIX');
	}
    
    //订单列表
    public function orderList() {
		$supplier_id = I('sid',0,'int');
		$export_flag = I('out',0,'int');
		$end_time = trim(I('end_time'));

		if($supplier_id <= 0) {
			$this->error('参数错误');
		}
		$max_date = date('Y-m-d ',strtotime('-1 day',time()));
		$query_date = $max_date;
		if(strtotime($end_time) !== false) {
			$query_date = strtotime(date('Y-m-d',strtotime($end_time))) > strtotime($query_date) ? $query_date : date('Y-m-d',strtotime($end_time));
		}
		
		$start = $query_date . ' 00:00:00';
		$end =  $query_date . ' 23:59:59';
		
		$where['supplier_id'] = $supplier_id;
		$where['pay_time'][] = array('egt', $start);
		$where['pay_time'][] = array('elt', $end);
		$where['order_type'] = array('in', array(0,3));
		
		$order_detail_model = M('supplier_order_pay_remittance_detail');
		
		
		$count = $order_detail_model->where($where)->count();
		
		$Page = new \Think\Page($count,$pageSize);
		
		$offset = $Page->firstRow;
		$_page = $Page->show();
		$_total = $Page->totalRows;
		
		$myfield = 'supplier_name,order_sn,order_type,pay_price,pay_time,factorage';
		$list = $order_detail_model->where($where)->field($myfield)->limit($offset, $pageSize)->select();
		
		$order_model = M('order');
		$order_where = array();
		
		foreach($list as $key=>$val){
		    $list[$key]['order_type'] = ($val['order_type']==3)? '预付款' : '普通订单';
		    $list[$key]['pay_time'] = substr($val['pay_time'], 0, 10);
		    $list[$key]['dprice'] = $val['pay_price'] - $val['factorage'];
		    //如果是普通订单 则查询订单id
		    if($val['order_type'] == 0){
		        $order_where['order_sn'] = $val['order_sn'];
		        $list[$key]['oid'] = $order_model->where($order_where)->getField('id');
		        $order_where = array();
		    }
		    
		}
        
		$supplier_name = $list[0]['supplier_name'];
		
		if(in_array($export_flag,array(1))) {
			$data_title = array(
				'supplier_name' => '经销商名称',
				'order_type'=>'订单类型',
				'order_sn' => '订单号',
				'pay_time'=>'订单日期',
				'pay_price'=>'订单金额',
				'factorage'=>'手续费',
				'dprice'=>'打款金额',

			);
			$export_data = $list;
			//经销商销售明细
			exportExcel($export_data,$data_title, 'Detail_summary_'.$query_date);
		}

		$this->meta_title = '经销商订单汇总列表明细';
		$this->select_menu = U('SupplierOrder/orderList');
		$this->assign('supplier_name',$supplier_name);
		$this->assign('list', $list);
		$this->assign('page', $_page);
		$this->assign('param',array('query_date'=>$query_date,'max_date'=>$max_date));
		$this->display();
    }


	//经销商销售订单汇总
    public function supplier(){
		$supplier_name = I('supplier_name',null,'htmlspecialchars');
		$export_flag = I('out',0,'int');
		$end_time = trim(I('end_time'));
		$max_date = date('Y-m-d ',strtotime('-1 day',time()));
		$query_date = $max_date;

		if(strtotime($end_time) !== false) {
			$query_date = strtotime(date('Y-m-d',strtotime($end_time))) > strtotime($query_date) ? $query_date : date('Y-m-d',strtotime($end_time));
		}

		$condition = array('pay_date'=>$query_date);
		if(strlen($supplier_name) > 0) {
			$condition['supplier_name'] = trim($supplier_name);
		}

		$sale_summary_model = M('admin_supplier_sale_summary');
		$count = $sale_summary_model->where($condition)->count();
		
		$Page = new \Think\Page($count);	
		$Page->setConfig('theme','%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END% %HEADER%');
		
		$_page = $Page->show();
			
		$list = $sale_summary_model->where($condition)->limit($Page->firstRow.','.$Page->listRows)->select();

		if(in_array($export_flag,array(1,2))) {
			$list = $sale_summary_model->where($condition)->select();
			$export_data = $list;
			switch($export_flag) {
				case 1: //汇总列表
					$data_title = array(
						'supplier_name'=>array('title'=>'经销商名','width'=>50),
						'pay_date' =>array('title'=>'汇总日期','width'=>20),
						'amount'=>array('title'=>'订单金额','width'=>20),
						'factorage'=>array('title'=>'手续费','width'=>20),
					);
					//经销商销售汇总
					exportExcel($export_data,$data_title, 'Order_summary'.$query_date);
					break;
				case 2: //付款汇总
				    //公司账号
    		        $company_account = C('PUBLIC_ACCOUNT')?:'4000025019200934677';
    		        
    		        $supplier_info_model = M('supplier_info');
    		        $supplier_where = array('supplier_id'=>0);
    		        $supplier_field = 'transfer_bank_a,transfer_bank';
    		        $my_supplier_info = array();
    		        
				    foreach($export_data as $key=>$val){
				        $export_data[$key]['transfer_type']= '';
				        $export_data[$key]['payer_purpose']= '';
				        $export_data[$key]['urgent_flag']= '';
				        $export_data[$key]['payer_account']= $company_account;
				        $export_data[$key]['transfer_bank']= $export_data[$key]['transfer_bank_a'];
				        
				        //查询开户行和网点名称
				        $supplier_where = array(
				            'supplier_id'=>$val['supplier_id']
				        );
				        $my_supplier_info = $supplier_info_model->where($supplier_where)->field($supplier_field)->find();
				        $export_data[$key]['transfer_bank_a']= $my_supplier_info['transfer_bank_a'];
				        $export_data[$key]['transfer_bank']= $my_supplier_info['transfer_bank'];
				        $export_data[$key]['dprice']= $val['amount'] -  $val['factorage'];
				    }
					$data_title = array(
						'transfer_type'=>array('title'=>'转账类型','width'=>20),
						'payer_account'=>array('title'=>'付款单位账号','width'=>30),//特定账号,公司账号 0039298903002556838
						'transfer_account'=>array('title'=>'收款单位账号','width'=>30),
						'transfer_name'=>array('title'=>'收款单位名称','width'=>45),
						'transfer_bank'=>array('title'=>'收款单位开户行名','width'=>45),
						'transfer_bank_a'=>array('title'=>'收款单位网点名称','width'=>45),
						'transfer_bank_n'=>array('title'=>'收款银行行号','width'=>20),
						'amount'=>array('title'=>'付款金额','width'=>20),
						'factorage'=>array('title'=>'手续费','width'=>20),
						'dprice'=>array('title'=>'付款金额','width'=>20),
						'payer_purpose'=>array('title'=>'付款用途','width'=>30),//为空不填写
						'urgent_flag'=>array('title'=>'加急标志','width'=>30), //为空不填写
					);
					//经销商付款汇总
					exportExcel($export_data,$data_title, 'Total_summary'.$query_date);
					break;
			}
		}
		$this->meta_title = '经销商订单汇总';
		$this->select_menu = U('SupplierOrder/supplier');
		$this->assign('list',$list);
		$this->assign('page',$_page);
		$this->assign('param',array('query_date'=>$query_date,'max_date'=>$max_date,'supplier_name'=>$supplier_name));
		$this->display();
    }            
}
?>